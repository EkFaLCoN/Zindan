# ZindanSistemi

Kurulum: ZindanSistemi.jar + (isteğe bağlı) PartySistemi, DropByDrop, CursedValleyMobsAndMob. MMOSURV_VAL resource pack'i güncelle (Asmadeus modeli).

## Komutlar (yetkili: zindan.admin)
- /zindan npc solo|parti  → bulunduğun yere NPC koyar (sağ tık menü). /zindan npcsil
- /zindan test <solo|parti> [kolay|normal|zor|olumcul]  → partisiz/limitsiz deneme girişi
- /zindan drop ekle mob <anahtar|tum> <yüzde>   (elindeki eşya)
- /zindan drop ekle sandik <solo|parti> <oda 1-7|hepsi> <yüzde>
- /zindan drop liste | sil <tablo> <no> | anahtarlar
- /zindan premium kart <oyuncu> [adet] [gün] | ver <oyuncu> [gün] | al <oyuncu>
- /zindan model [a|b]  → Asmadeus vitrini (model ters/dağınık görünürse b dene, sonra config: asmadeus.model-varyanti)
- /zindan cik, /zindan bilgi, /zindan bitir, /zindan sifirla <oyuncu>, /zindan reload
