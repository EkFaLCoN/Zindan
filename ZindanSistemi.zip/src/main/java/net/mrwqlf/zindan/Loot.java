package net.mrwqlf.zindan;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Drop tabloları (loot.yml): yaratık/boss ve sandık. Sahip ayarlar:
 *   /zindan drop ekle mob <anahtar|tum> <yüzde>
 *   /zindan drop ekle sandik <solo|parti> <oda|hepsi> <yüzde>
 * Ayrıca DropByDrop çöp havuzu (kademe tablosu; bosslar yalnız Kadim %1) ve Drop Premium çarpanı.
 */
public final class Loot {
    public record Giris(ItemStack esya, double yuzde) {
    }

    public record Cop(ItemStack esya, int kademe) {
    }

    private final ZindanSistemi pl;
    private final File dosya;
    /** Anahtar: mob.<ad> veya sandik.<tip>.<oda|hepsi> */
    private final Map<String, List<Giris>> tablolar = new LinkedHashMap<>();
    private final List<Cop> copHavuzu = new ArrayList<>();

    public Loot(ZindanSistemi pl) {
        this.pl = pl;
        this.dosya = new File(pl.getDataFolder(), "loot.yml");
        yukle();
    }

    // ------------------------------------------------------------------ saklama

    public void yukle() {
        tablolar.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        ConfigurationSection kok = y.getConfigurationSection("tablolar");
        if (kok == null) return;
        for (String anahtar : kok.getKeys(false)) {
            List<Giris> liste = new ArrayList<>();
            for (Map<?, ?> m : kok.getMapList(anahtar)) {
                try {
                    byte[] b = Base64.getDecoder().decode(String.valueOf(m.get("esya")));
                    ItemStack it = ItemStack.deserializeBytes(b);
                    double yuzde = Double.parseDouble(String.valueOf(m.get("yuzde")));
                    liste.add(new Giris(it, yuzde));
                } catch (RuntimeException e) {
                    pl.getLogger().warning("loot.yml kaydı okunamadı (" + anahtar + "): " + e.getMessage());
                }
            }
            tablolar.put(anahtar, liste);
        }
    }

    public void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, List<Giris>> e : tablolar.entrySet()) {
            List<Map<String, Object>> l = new ArrayList<>();
            for (Giris g : e.getValue()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("esya", Base64.getEncoder().encodeToString(g.esya().serializeAsBytes()));
                m.put("yuzde", g.yuzde());
                l.add(m);
            }
            y.set("tablolar." + e.getKey(), l);
        }
        try {
            y.save(dosya);
        } catch (IOException ex) {
            pl.getLogger().warning("loot.yml yazılamadı: " + ex.getMessage());
        }
    }

    public List<Giris> tablo(String anahtar) {
        return tablolar.computeIfAbsent(anahtar, k -> new ArrayList<>());
    }

    public Map<String, List<Giris>> hepsi() {
        return tablolar;
    }

    // ------------------------------------------------------------------ çöp havuzu (DropByDrop)

    /** DropByDrop'un tüm çöp eşyalarını yansımayla yükler. @return adet; eklenti yoksa -1 */
    public int copYukle() {
        Plugin p = Bukkit.getPluginManager().getPlugin("DropByDrop");
        if (p == null || !p.isEnabled()) return -1;
        try {
            Object katalog = p.getClass().getMethod("katalog").invoke(p);
            List<?> tanimlar = (List<?>) katalog.getClass().getMethod("hepsi").invoke(katalog);
            Method uret = null;
            for (Method m : katalog.getClass().getMethods()) {
                if (m.getName().equals("uret") && m.getParameterCount() == 1) uret = m;
            }
            if (uret == null) return -1;
            copHavuzu.clear();
            for (Object t : tanimlar) {
                ItemStack it = (ItemStack) uret.invoke(katalog, t);
                int kademe = 1;
                ItemMeta m = it.getItemMeta();
                if (m != null && m.hasItemModel() && m.getItemModel() != null) {
                    String key = m.getItemModel().getKey();
                    try {
                        kademe = Integer.parseInt(key.substring(key.lastIndexOf('_') + 1));
                    } catch (RuntimeException ignored) {
                        // kademe okunamazsa 1
                    }
                }
                copHavuzu.add(new Cop(it, Math.max(1, Math.min(7, kademe))));
            }
            return copHavuzu.size();
        } catch (ReflectiveOperationException | RuntimeException e) {
            pl.getLogger().warning("DropByDrop çöp eşyaları yüklenemedi: " + e);
            return -1;
        }
    }

    public int copSayisi() {
        return copHavuzu.size();
    }

    // ------------------------------------------------------------------ zar

    /**
     * Yaratık/boss ganimeti. boss=true ise çöp havuzundan yalnızca Kadim kademe (boss-cop.yuzde) düşer;
     * normal yaratıklar kademe tablosunu kullanır. Drop Premium tüm şansları ikiye katlar; zorluk drop çarpanı (kolay ×1 ... ölümcül ×3) üstüne biner.
     */
    public List<ItemStack> mobZar(String mobAnahtar, boolean boss, Player vuran, Zorluk zorluk) {
        double carpan = Premium.carpan(vuran) * (zorluk == null ? 1.0 : zorluk.drop);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        List<ItemStack> kazanilan = new ArrayList<>();
        for (String k : new String[]{"mob." + mobAnahtar, "mob.tum"}) {
            for (Giris g : tablolar.getOrDefault(k, List.of())) {
                if (r.nextDouble() < Math.min(1.0, g.yuzde() / 100.0 * carpan)) {
                    kazanilan.add(g.esya().clone());
                }
            }
        }
        if (pl.getConfig().getBoolean("cop-drop.aktif", true)) {
            int bossKademe = pl.getConfig().getInt("cop-drop.boss.kademe", 7);
            double bossYuzde = pl.getConfig().getDouble("cop-drop.boss.yuzde", 1.0);
            for (Cop c : copHavuzu) {
                double yuzde;
                if (boss) {
                    if (c.kademe() != bossKademe) continue;
                    yuzde = bossYuzde;
                } else {
                    yuzde = pl.getConfig().getDouble("cop-drop.kademe-yuzde." + c.kademe(), 0.001);
                }
                if (r.nextDouble() < Math.min(1.0, yuzde / 100.0 * carpan)) {
                    kazanilan.add(c.esya().clone());
                }
            }
        }
        return kazanilan;
    }

    /** Sandık içeriği: o odaya ve "hepsi"ne tanımlı kayıtların her biri için ayrı zar. Premium sandığı etkilemez; zorluk çarpanı etkiler (config: zorluk-drop-sandiga-uygula). */
    public List<ItemStack> sandikZar(String tip, int oda, Zorluk zorluk) {
        double carpan = zorluk != null && pl.getConfig().getBoolean("zorluk-drop-sandiga-uygula", true) ? zorluk.drop : 1.0;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        List<ItemStack> kazanilan = new ArrayList<>();
        for (String k : new String[]{"sandik." + tip + ".hepsi", "sandik." + tip + "." + oda}) {
            for (Giris g : tablolar.getOrDefault(k, List.of())) {
                if (r.nextDouble() < Math.min(1.0, g.yuzde() / 100.0 * carpan)) {
                    kazanilan.add(g.esya().clone());
                }
            }
        }
        return kazanilan;
    }
}
