package net.mrwqlf.zindan;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.*;
import org.bukkit.GameMode;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.function.Consumer;

/** Çalışan bir zindan: harita, odalar, yaratıklar, sandıklar, zamanlayıcı. */
public final class Instance {
    public enum Durum { KURULUYOR, CALISIYOR, BITIYOR }

    final ZindanSistemi pl;
    final String id;
    public final boolean parti;
    public final Zorluk z;
    public final World w;
    final int slot, ox, oy = 64, oz = 0;
    final boolean deneme;
    final List<Oda> odalar;
    final List<Yapi.Kutu> kutular;
    final List<Yapi.Kutu> sandikKutulari = new ArrayList<>();
    public final Set<UUID> uyeler = new LinkedHashSet<>();
    final Map<UUID, Location> donus = new HashMap<>();
    public final Map<UUID, MobBilgi> moblar = new HashMap<>();
    final Set<UUID> odaHedef = new HashSet<>();
    final List<UUID> minyonlar = new ArrayList<>();
    final boolean[] temiz, basladi;
    int aktifOda = -1;
    public Durum durum = Durum.KURULUYOR;
    long bitisMs;
    BossBar zamanBar;
    BukkitTask gorev;
    AsmadeusBoss asmadeus;
    final List<MiniOverlord> overlordlar = new ArrayList<>();
    final Random rnd = new Random();
    final Map<UUID, Integer> dusme = new HashMap<>();
    final Map<Long, Map<UUID, Inventory>> sandikEnv = new HashMap<>();
    final Set<Long> acikSandiklar = new HashSet<>();
    final Map<Long, Integer> sandikOda = new HashMap<>();
    long hepsiOfflineBaslangic = 0;
    int tickSayac = 0;
    boolean temizlikte = false;
    final Set<Long> biletler = new HashSet<>();

    public Instance(ZindanSistemi pl, String id, boolean parti, Zorluk z, World w, int slot, boolean deneme) {
        this.pl = pl;
        this.id = id;
        this.parti = parti;
        this.z = z;
        this.w = w;
        this.slot = slot;
        this.deneme = deneme;
        this.ox = (slot % 8) * 500;
        this.odalar = Yapi.planla(parti, ox, oy, oz);
        this.kutular = Yapi.uret(odalar, parti);
        this.temiz = new boolean[odalar.size()];
        this.basladi = new boolean[odalar.size()];
    }

    public static long anahtar(int x, int y, int z) {
        return ((long) x & 0x3FFFFFFL) << 38 | ((long) z & 0x3FFFFFFL) << 12 | ((long) y & 0xFFFL);
    }

    // ================================================================== başlatma

    /** Oyuncunun doğacağı noktanın altı katı değilse küçük bir taban koyar (boşluğa düşmeyi önler). */
    private Location guvenli(Location l) {
        org.bukkit.block.Block alt = l.clone().add(0, -1, 0).getBlock();
        if (alt.isPassable() || alt.isLiquid()) {
            alt.setType(Material.STONE, false);
        }
        for (int dy = 0; dy <= 2; dy++) {
            org.bukkit.block.Block b = l.clone().add(0, dy, 0).getBlock();
            if (!b.isPassable()) b.setType(Material.AIR, false);
        }
        return l;
    }

    public void baslat(Collection<Player> ps) {
        tumChunkBileti();
        for (Player p : ps) {
            uyeler.add(p.getUniqueId());
            donus.put(p.getUniqueId(), p.getLocation().clone());
            pl.veri.donusKaydet(p, p.getLocation());
            pl.oyuncuInstance.put(p.getUniqueId(), this);
            ZindanSistemi.msj(p, "§7Zindan hazırlanıyor, lütfen bekle...");
        }
        isle(kutular, this::hazir);
    }

    /** Zindan süre sınırı yalnızca config'te sure-sinirli: true ise vardır; varsayılan: /zindan cik denmedikçe bitmez. */
    boolean sureli() {
        return pl.getConfig().getBoolean("sure-sinirli", false);
    }

    private void hazir() {
        if (durum == Durum.BITIYOR) return;     // kurulurken herkes çıktıysa başlatma
        durum = Durum.CALISIYOR;
        int dk = pl.getConfig().getInt("sure-dakika", 60);
        bitisMs = sureli() ? System.currentTimeMillis() + dk * 60_000L : 0L;
        zamanBar = Bukkit.createBossBar("§eZindan", BarColor.YELLOW, BarStyle.SOLID);
        Oda ilk = odalar.get(0);
        for (UUID u : new ArrayList<>(uyeler)) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            zamanBar.addPlayer(p);
            p.teleport(guvenli(ilk.giris(w)));
            p.setFallDistance(0);
            p.sendTitle(z.renk + "§l" + (parti ? "PARTİ ZİNDANI" : "SOLO ZİNDAN"),
                    "§7Zorluk: " + z.renk + z.ad + (sureli() ? " §8| §7Süre: " + dk + " dk" : ""), 10, 70, 20);
            ZindanSistemi.msj(p, "§aZindana girdin! §7Eşyaların ölümde düşmez; tüm ganimet sana aittir. "
                    + (sureli() ? dk + " dakika içinde bitir!" : "Çıkmak için §f/zindan cik §7yaz; sen demedikçe zindan bitmez."));
        }
        gorev = new BukkitRunnable() {
            @Override
            public void run() {
                tick();
            }
        }.runTaskTimer(pl, 20L, 5L);
        Bukkit.getScheduler().runTaskLater(pl, () -> odaBasla(0), 100L);
    }

    /** Kutuları tick başına sınırlı sayıda bloğa yayarak uygular. */
    private void isle(List<Yapi.Kutu> liste, Runnable bitince) {
        final int limit = Math.max(1000, pl.getConfig().getInt("yapi-blok-tick", 10000));
        new BukkitRunnable() {
            int ki = 0;
            int x, y, zz;
            boolean basla = false;

            @Override
            public void run() {
                if (durum == Durum.BITIYOR && !temizlikte) {
                    cancel();           // kurulum iptal; temizlik zaten tüm kutuları siler
                    return;
                }
                int say = 0;
                while (ki < liste.size() && say < limit) {
                    Yapi.Kutu k = liste.get(ki);
                    if (!basla) {
                        x = k.x1();
                        y = k.y1();
                        zz = k.z1();
                        basla = true;
                    }
                    w.getBlockAt(x, y, zz).setBlockData(k.veri(), false);
                    say++;
                    if (++zz > k.z2()) {
                        zz = k.z1();
                        if (++y > k.y2()) {
                            y = k.y1();
                            if (++x > k.x2()) {
                                ki++;
                                basla = false;
                            }
                        }
                    }
                }
                if (ki >= liste.size()) {
                    cancel();
                    bitince.run();
                }
            }
        }.runTaskTimer(pl, 1L, 1L);
    }

    // ================================================================== yardımcılar

    public List<Player> aktifOyuncular() {
        List<Player> l = new ArrayList<>();
        for (UUID u : uyeler) {
            Player p = Bukkit.getPlayer(u);
            if (p != null && p.isOnline() && p.getWorld().equals(w) && !p.isDead() && p.getGameMode() != GameMode.SPECTATOR) {
                l.add(p);
            }
        }
        return l;
    }

    public Player enYakin(Location l, double maks) {
        Player best = null;
        double bd = maks * maks;
        for (Player p : aktifOyuncular()) {
            double d = p.getLocation().distanceSquared(l);
            if (d < bd) {
                bd = d;
                best = p;
            }
        }
        return best;
    }

    public void herkeseBaslik(String ust, String alt) {
        for (Player p : aktifOyuncular()) p.sendTitle(ust, alt, 10, 50, 15);
    }

    public void herkeseMesaj(String s) {
        for (UUID u : uyeler) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) ZindanSistemi.msj(p, s);
        }
    }

    public Oda oda(int i) {
        return odalar.get(i);
    }

    public int sayi(int taban) {
        return Math.max(1, (int) Math.round(taban * z.sayi));
    }

    /** Oyuncunun yeniden doğacağı kontrol noktası. */
    public Location kontrolNoktasi() {
        int i = Math.max(0, aktifOda);
        Oda o = odalar.get(i);
        // oda henüz hiç aktifleşmediyse bir önceki odanın çıkışı değil, o odanın girişi
        return guvenli(o.giris(w));
    }

    // ================================================================== yaratık üretimi

    /**
     * Zindan yaratığı üretir. hp*zorluk 900'ü aşarsa sanal can kullanılır.
     * odulVer=false: minyon (drop vermez, oda hedefi değildir).
     */
    public <T extends LivingEntity> T mobYap(Class<T> c, Location l, String anahtar, String ad, double tabanHp,
                                             boolean boss, boolean olcekHasar, boolean odulVer, int oda, Consumer<T> ek) {
        double hp = tabanHp * z.hp;
        final boolean sanal = hp > 900;
        MobBilgi b = new MobBilgi(this, anahtar, ad, boss, olcekHasar, odulVer, oda);
        b.sanal = sanal;
        b.vmax = hp;
        b.vhp = hp;
        T e = w.spawn(l, c, ent -> {
            ent.addScoreboardTag("zd");
            ent.setPersistent(true);              // kaybolmasın (açılışta eski "zd" varlıklar zaten temizlenir)
            ent.setRemoveWhenFarAway(false);
            if (ent instanceof Mob m) m.setCanPickupItems(false);
            var a = ent.getAttribute(Attribute.MAX_HEALTH);
            if (a != null) a.setBaseValue(sanal ? 100.0 : hp);
            ent.setHealth(sanal ? 100.0 : hp);
            if (ek != null) ek.accept(ent);
        });
        b.varlik = e;
        moblar.put(e.getUniqueId(), b);
        pl.tumMoblar.put(e.getUniqueId(), b);
        if (odulVer) odaHedef.add(e.getUniqueId());
        else minyonlar.add(e.getUniqueId());
        if (e instanceof Mob m) {
            Player p = enYakin(l, 80);
            if (p != null && !(e instanceof Warden)) m.setTarget(p);
            if (e instanceof Warden wd && p != null) wd.setAnger(p, 150);
        }
        return e;
    }

    private void efektler(LivingEntity e) {
        e.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 1, false, false));
        e.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, PotionEffect.INFINITE_DURATION, 0, false, false));
    }

    public MobBilgi bossBar(LivingEntity e, String baslik, BarColor renk) {
        MobBilgi b = moblar.get(e.getUniqueId());
        if (b == null) return null;
        b.bar = Bukkit.createBossBar(baslik, renk, BarStyle.SEGMENTED_10);
        for (Player p : aktifOyuncular()) b.bar.addPlayer(p);
        return b;
    }

    /** Minyon (drop vermeyen yardımcı) üretir. */
    public <T extends LivingEntity> T minyon(Class<T> c, Location l, String anahtar, double tabanHp, Consumer<T> ek) {
        return mobYap(c, l, anahtar, anahtar, tabanHp, false, true, false, aktifOda, ek);
    }

    // ================================================================== odalar

    public void odaBasla(int i) {
        if (durum != Durum.CALISIYOR || i < 0 || i >= odalar.size() || basladi[i]) return;
        basladi[i] = true;
        aktifOda = i;
        chunkBilet(i);
        Oda o = odalar.get(i);
        herkeseBaslik("§c§l" + (i + 1) + ". ODA", o.tur == Oda.Tur.PARKUR ? "§7Parkur: düşersen odanın başına dönersin" : "§7Hepsini temizle!");
        for (Player p : aktifOyuncular()) p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.4f);
        if (o.tur == Oda.Tur.PARKUR) {
            parkurBas = System.currentTimeMillis();
            parkurUyarildi.clear();
            parkurBitirdi.clear();
            return;
        }
        if (parti) partiOdasi(o); else soloOdasi(o);
        if (odaHedef.isEmpty()) odaTemiz(i);
    }

    /** Aktif oda ve komşuları yüklü kalsın: yaratıklar chunk boşaltılınca kaybolmasın. */
    private void chunkBilet(int i) {
        // tüm yapı baslat()'ta zaten tutuluyor; burada yapılacak bir şey kalmadı
    }

    /**
     * Tüm zindan alanının chunk'larını kurulumdan önce tutar. Aksi halde (dünya otomatik kaydı kapalı olduğundan)
     * inşa edilen chunk'lar boşaltılınca blokları kaybolur: oyuncu boşluğa düşer, yaratıklar kaybolur.
     */
    private void tumChunkBileti() {
        Set<Long> yeni = new HashSet<>();
        for (int j = 0; j < odalar.size(); j++) {
            Oda o = odalar.get(j);
            for (int cx = (o.x0 - 8) >> 4; cx <= (o.x0 + o.len + 16) >> 4; cx++)
                for (int cz = (o.oz - o.hw - 8) >> 4; cz <= (o.oz + o.hw + 8) >> 4; cz++)
                    yeni.add(((long) cx << 32) | (cz & 0xFFFFFFFFL));
        }
        for (long k : new ArrayList<>(biletler)) {
            if (!yeni.contains(k)) w.removePluginChunkTicket((int) (k >> 32), (int) k, pl);
        }
        for (long k : yeni) {
            if (!biletler.contains(k)) w.addPluginChunkTicket((int) (k >> 32), (int) k, pl);
        }
        biletler.clear();
        biletler.addAll(yeni);
    }

    private Location nokta(Oda o) {
        return o.rastgele(w, rnd);
    }

    private void soloOdasi(Oda o) {
        switch (o.index) {
            case 0 -> {
                for (int i = 0; i < sayi(10); i++)
                    mobYap(Evoker.class, nokta(o), "evoker", "Çağırıcı", 50, false, true, true, 0, null);
            }
            case 1 -> {
                for (int i = 0; i < sayi(10); i++)
                    mobYap(Witch.class, nokta(o), "cadi", "Cadı", 75, false, true, true, 1, null);
            }
            case 2 -> {
                for (int i = 0; i < sayi(12); i++)
                    mobYap(Wolf.class, nokta(o), "kara_kurt", "Kara Kurt", 85, false, true, true, 2, k -> {
                        k.setVariant(Wolf.Variant.BLACK);
                        k.setAngry(true);
                    });
            }
            case 3 -> {
                for (int i = 0; i < sayi(10); i++) {
                    Location l = nokta(o);
                    SkeletonHorse at = mobYap(SkeletonHorse.class, l, "iskelet_at", "İskelet At", 50, false, true, true, 3, a -> {
                        a.setTamed(true);
                        a.setAdult();
                    });
                    Skeleton s = mobYap(Skeleton.class, l, "iskelet_binici", "İskelet", 40, false, true, true, 3, sk -> {
                        sk.getEquipment().setItemInMainHand(new ItemStack(Material.BOW));
                    });
                    at.addPassenger(s);
                }
            }
            case 4 -> {
                for (int i = 0; i < sayi(12); i++)
                    mobYap(PiglinBrute.class, nokta(o), "piglin_brute", "Piglin Brute", 80, false, true, true, 4,
                            b -> b.setImmuneToZombification(true));
            }
            case 5 -> {
                for (int i = 0; i < 6; i++)
                    mobYap(Warden.class, nokta(o), "warden", "Warden", 500, false, false, true, 5, null);
            }
            default -> {
                Location l = o.merkez(w).add(8, 0, 0);
                overlordlar.add(MiniOverlord.yap(this, l, o.index));
            }
        }
    }

    private void partiOdasi(Oda o) {
        switch (o.index) {
            case 0 -> {
                for (int i = 0; i < sayi(20); i++)
                    mobYap(Zombie.class, nokta(o), "zombi", "Zombi", 100, false, true, true, 0, zb -> {
                        zb.setShouldBurnInDay(false);
                        zb.setBaby(false);
                        efektler(zb);
                    });
            }
            case 1 -> {
                for (int i = 0; i < sayi(12); i++)
                    mobYap(WitherSkeleton.class, nokta(o), "wither_iskelet", "Wither İskelet", 120, false, true, true, 1,
                            this::efektler);
                Warden wd = mobYap(Warden.class, o.merkez(w).add(6, 0, 0), "warden_mini", "Zindan Muhafızı", 2000, true,
                        false, true, 1, null);
                bossBar(wd, "§3§lZindan Muhafızı (Warden)", BarColor.BLUE);
                MobBilgi b = moblar.get(wd.getUniqueId());
                if (b != null) b.sayac = 200;
            }
            case 3 -> {
                Location l = o.merkez(w).add(6, 0, 0);
                Ravager rv = mobYap(Ravager.class, l, "ravager_mini", "Ravager", 1500, true, true, true, 3, null);
                PiglinBrute br = mobYap(PiglinBrute.class, l, "piglin_binici", "Piglin Brute", 1500, true, true, true, 3,
                        b -> b.setImmuneToZombification(true));
                rv.addPassenger(br);
                bossBar(rv, "§c§lRavager", BarColor.RED);
                bossBar(br, "§6§lPiglin Brute (binici)", BarColor.YELLOW);
            }
            case 4 -> {
                for (int i = 0; i < sayi(25); i++)
                    mobYap(Bogged.class, nokta(o), "bogged", "Zehirli İskelet", 100, false, true, true, 4, null);
            }
            default -> {
                asmadeus = new AsmadeusBoss(this, o);
            }
        }
    }

    public void odaTemiz(int i) {
        if (temiz[i]) return;
        temiz[i] = true;
        Oda o = odalar.get(i);
        // yardımcıları temizle
        for (UUID u : new ArrayList<>(minyonlar)) {
            Entity e = Bukkit.getEntity(u);
            if (e != null) e.remove();
            moblar.remove(u);
            pl.tumMoblar.remove(u);
        }
        minyonlar.clear();
        for (Entity e : w.getEntitiesByClass(Vex.class)) {
            if (o.icinde(e.getLocation())) e.remove();
        }
        herkeseBaslik("§a§lODA TEMİZLENDİ", o.son ? "§6Sandıklar açıldı!" : "§7Kapı açıldı, sandıklardan ödülünü al");
        for (Player p : aktifOyuncular()) p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        // kapı
        if (!o.son) {
            int[] kp = o.kapi();
            int[] br = o.kapiBariyer();
            for (int y = kp[1]; y <= kp[3]; y++)
                for (int zz = kp[2]; zz <= kp[4]; zz++) {
                    w.getBlockAt(kp[0], y, zz).setType(Material.AIR, false);
                    w.getBlockAt(br[0], y, zz).setType(Material.AIR, false);
                }
            w.playSound(new Location(w, kp[0], kp[1], o.oz), Sound.BLOCK_IRON_DOOR_OPEN, 2f, 0.6f);
        }
        // sandıklar
        for (int[] p : o.sandikKonumlari()) {
            Yapi.Kutu k = Yapi.sandik(o, p);
            w.getBlockAt(p[0], p[1], p[2]).setBlockData(k.veri(), false);
            sandikKutulari.add(Yapi.hava(k));
            long key = anahtar(p[0], p[1], p[2]);
            acikSandiklar.add(key);
            sandikOda.put(key, i);
            w.spawnParticle(Particle.TOTEM_OF_UNDYING, p[0] + 0.5, p[1] + 1.2, p[2] + 0.5, 25, 0.3, 0.4, 0.3, 0.1);
        }
        if (o.son) zafer();
    }

    private void zafer() {
        herkeseBaslik("§6§l★ ZİNDAN TAMAMLANDI ★", z.renk + z.ad + " §7modunda zindanı bitirdin!");
        if (pl.getConfig().getBoolean("zafer-otomatik-bitir", false)) {
            int bekle = pl.getConfig().getInt("zafer-bekleme-sn", 120);
            herkeseMesaj("§6Zindan tamamlandı! §7Sandıklardan ödüllerini al. §e" + bekle + " saniye §7sonra dışarı çıkarılacaksın.");
            Bukkit.getScheduler().runTaskLater(pl, () -> {
                if (durum == Durum.CALISIYOR) bitir("Zindan tamamlandı.");
            }, bekle * 20L);
        } else {
            herkeseMesaj("§6Zindan tamamlandı! §7Sandıklardan ödüllerini al. Hazır olunca §f/zindan cik §7yaz — sen demedikçe zindan kapanmaz.");
        }
    }

    // ================================================================== ödül / ölüm

    public void mobOldu(MobBilgi b, UUID id, Player vuranOlay) {
        moblar.remove(id);
        pl.tumMoblar.remove(id);
        odaHedef.remove(id);
        minyonlar.remove(id);
        if (b.bar != null) {
            b.bar.removeAll();
            b.bar = null;
        }
        if (b.odulVer) {
            Player alici = null;
            double enCok = -1;
            for (Map.Entry<UUID, Double> e : b.hasar.entrySet()) {
                Player p = Bukkit.getPlayer(e.getKey());
                if (p != null && p.isOnline() && uyeler.contains(e.getKey()) && e.getValue() > enCok) {
                    enCok = e.getValue();
                    alici = p;
                }
            }
            if (alici == null) alici = vuranOlay;
            if (alici == null && !aktifOyuncular().isEmpty()) alici = aktifOyuncular().get(0);
            if (alici != null) odul(alici, b);
        }
        if (b.odulVer && !temiz[b.oda] && basladi[b.oda] && odaHedef.isEmpty()) {
            odaTemiz(b.oda);
        }
    }

    private void odul(Player p, MobBilgi b) {
        List<ItemStack> l = pl.loot.mobZar(b.anahtar, b.boss, p, z);
        for (ItemStack it : l) {
            Map<Integer, ItemStack> kalan = p.getInventory().addItem(it);
            if (!kalan.isEmpty()) {
                // envanter dolu: yere atma (kaybolabilir), zindan çıkışında teslim edilecek ganimet çantasına koy
                pl.veri.bekleyenEkle(p.getUniqueId(), new ArrayList<>(kalan.values()));
                ZindanSistemi.msj(p, "§eEnvanterin dolu! §7Bu eşya ganimet çantana kondu, zindandan çıkınca verilecek.");
            }
            String ad = it.hasItemMeta() && it.getItemMeta().hasDisplayName() ? it.getItemMeta().getDisplayName() : it.getType().name();
            ZindanSistemi.msj(p, "§a+ §f" + it.getAmount() + "x " + ad + (Premium.aktif(p) ? " §6(Premium)" : ""));
        }
    }

    // ================================================================== sandık

    public boolean sandikAc(Player p, Block blok) {
        long key = anahtar(blok.getX(), blok.getY(), blok.getZ());
        if (!acikSandiklar.contains(key)) return false;
        Map<UUID, Inventory> m = sandikEnv.computeIfAbsent(key, k -> new HashMap<>());
        Inventory inv = m.get(p.getUniqueId());
        if (inv == null) {
            inv = Bukkit.createInventory(null, 27, "§6Zindan Sandığı");
            List<ItemStack> l = pl.loot.sandikZar(parti ? "parti" : "solo", sandikOda.getOrDefault(key, 0) + 1, z);
            List<Integer> yer = new ArrayList<>();
            for (int i = 0; i < 27; i++) yer.add(i);
            Collections.shuffle(yer, rnd);
            for (int i = 0; i < l.size() && i < 27; i++) inv.setItem(yer.get(i), l.get(i));
            m.put(p.getUniqueId(), inv);
            if (l.isEmpty()) ZindanSistemi.msj(p, "§7Bu sandık senin için boş çıktı.");
        }
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1f);
        return true;
    }

    // ================================================================== tick

    private void tick() {
        if (durum != Durum.CALISIYOR) return;
        tickSayac += 5;
        if (sureli()) {
            long kalan = bitisMs - System.currentTimeMillis();
            if (kalan <= 0) {
                bitir("Süre doldu!");
                return;
            }
            if (zamanBar != null) {
                long sn = kalan / 1000;
                zamanBar.setTitle("§eZindan süresi: §f" + String.format("%02d:%02d", sn / 60, sn % 60));
                zamanBar.setProgress(Math.max(0.0, Math.min(1.0, kalan / (pl.getConfig().getInt("sure-dakika", 60) * 60_000.0))));
            }
        } else if (zamanBar != null) {
            zamanBar.setTitle("§eZindan §7— çıkmak için §f/zindan cik");
            zamanBar.setProgress(1.0);
        }
        if (sandikParcacik()) { /* yalnızca yan etki */ }

        // herkes çevrimdışıysa 3 dk sonra kapat
        List<Player> aktif = aktifOyuncular();
        boolean hicOnline = false;
        for (UUID u : uyeler) {
            Player p = Bukkit.getPlayer(u);
            if (p != null && p.isOnline()) hicOnline = true;
        }
        if (!hicOnline) {
            if (hepsiOfflineBaslangic == 0) hepsiOfflineBaslangic = System.currentTimeMillis();
            int terk = pl.getConfig().getInt("terk-dakika", 60);
            if (terk > 0 && System.currentTimeMillis() - hepsiOfflineBaslangic > terk * 60_000L) {
                bitir("Tüm oyuncular uzun süre ayrıldığı için zindan kapatıldı.");
                return;
            }
        } else {
            hepsiOfflineBaslangic = 0;
        }

        // aktif parkur: düşme + bitiş
        if (aktifOda >= 0 && odalar.get(aktifOda).tur == Oda.Tur.PARKUR) {
            parkurKontrol(odalar.get(aktifOda), aktif);
            parkurSureKontrol(odalar.get(aktifOda));
        }

        // sıradaki odayı aç
        if (aktifOda >= 0 && temiz[aktifOda] && aktifOda + 1 < odalar.size() && !basladi[aktifOda + 1]) {
            Oda sonraki = odalar.get(aktifOda + 1);
            for (Player p : aktif) {
                if (p.getLocation().getX() >= sonraki.x0 + 1 && sonraki.icinde(p.getLocation())) {
                    odaBasla(aktifOda + 1);
                    break;
                }
            }
        }

        // yaratık bakımı
        for (MobBilgi b : new ArrayList<>(moblar.values())) {
            LivingEntity e = b.varlik;
            if (e == null || !e.isValid()) continue;
            // kaçan / boşluğa düşen yaratığı odaya geri al
            if (!e.isInsideVehicle() && b.oda >= 0 && b.oda < odalar.size()) {
                Location el = e.getLocation();
                Oda bo = odalar.get(b.oda);
                if (el.getY() < oy - 6 && bo.tur != Oda.Tur.PARKUR || el.getX() < ox - 20 || el.getX() > ox + 480
                        || Math.abs(el.getZ() - oz) > 60) {
                    e.teleport(bo.rastgele(w, rnd));
                    e.setFallDistance(0);
                }
            }
            // yeniden hedefleme
            if (e instanceof Mob m && !(e instanceof Warden)) {
                LivingEntity t = m.getTarget();
                if (t == null || t.isDead() || !(t instanceof Player tp) || !uyeler.contains(tp.getUniqueId())) {
                    Player yakin = enYakin(e.getLocation(), 90);
                    if (yakin != null) m.setTarget(yakin);
                }
            } else if (e instanceof Warden wd && tickSayac % 40 == 0) {
                Player yakin = enYakin(e.getLocation(), 90);
                if (yakin != null) wd.setAnger(yakin, 150);
            }
            // iskelet at: kendi saldırısı
            if (e instanceof SkeletonHorse at) atSaldirisi(at, b);
            // boss yenilenmesi (zor / ölümcül)
            if (b.boss && z.yenilenme > 0 && b.sanal && b.vhp > 0 && tickSayac % 20 == 0) {
                b.vhp = Math.min(b.vmax, b.vhp + b.vmax * z.yenilenme);
                sanalCanYansit(b);
            }
            // bar
            if (b.bar != null) {
                b.bar.setProgress(Math.max(0.0, Math.min(1.0, b.canYuzde())));
                for (Player p : aktif) if (!b.bar.getPlayers().contains(p)) b.bar.addPlayer(p);
            }
            // zehirli iskelet / cadı iyileştirmesi
            if (b.anahtar.equals("cadi") && tickSayac % 20 == 0) cadiIyilestir((Witch) e, b);
            if (b.anahtar.equals("warden_mini")) wardenSonik((Warden) e, b);
        }
    }

    private boolean sandikParcacik() {
        if (tickSayac % 20 != 0 || acikSandiklar.isEmpty()) return false;
        for (long key : acikSandiklar) {
            int y = (int) (key & 0xFFFL);
            int x = (int) (key >> 38);
            if (x >= (1 << 25)) x -= (1 << 26);
            int zz = (int) ((key >> 12) & 0x3FFFFFFL);
            if (zz >= (1 << 25)) zz -= (1 << 26);
            w.spawnParticle(Particle.HAPPY_VILLAGER, x + 0.5, y + 1.3, zz + 0.5, 3, 0.25, 0.2, 0.25, 0.0);
        }
        return true;
    }

    private final Set<Long> kirilanlar = new HashSet<>();
    /** Parkur: oda açıldığı an; 5 dk sonra bitiremeyenlere uyarı, sonraki girişte bitişe ışınlama. */
    private long parkurBas = 0;
    private final Set<UUID> parkurUyarildi = new HashSet<>();
    private final Set<UUID> parkurBitirdi = new HashSet<>();

    private void parkurSureKontrol(Oda o) {
        if (parkurBas == 0) return;
        for (UUID u : uyeler) {
            Player p = Bukkit.getPlayer(u);
            if (p != null && p.isOnline() && o.bitisBolgesi(p.getLocation())) parkurBitirdi.add(u);
        }
        int dk = Math.max(1, pl.getConfig().getInt("parkur.yardim-dakika", 5));
        if (System.currentTimeMillis() - parkurBas < dk * 60_000L) return;
        for (UUID u : uyeler) {
            if (parkurBitirdi.contains(u) || !parkurUyarildi.add(u)) continue;
            Player p = Bukkit.getPlayer(u);
            if (p != null && p.isOnline()) {
                p.sendTitle("§e§lParkuru geçemedin mi?", "§7Oyundan çıkıp tekrar gir: parkurun sonuna ışınlanacaksın", 10, 100, 20);
                ZindanSistemi.msj(p, "§e" + dk + " dakikadır parkurdasın. §7Geçemiyorsan §fsunucudan çıkıp tekrar gir §7— parkurun sonuna ışınlanırsın. "
                        + "§8(Zindandan atılmazsın; §f/zindan cik §8demedikçe zindan sürer.)");
            }
        }
    }

    /** Oyuncu zindana (yeniden) girdiğinde: uyarılmış ve bitirememişse parkurun sonuna alır. */
    public void girisKontrol(Player p) {
        if (aktifOda < 0 || aktifOda >= odalar.size()) return;
        Oda o = odalar.get(aktifOda);
        UUID u = p.getUniqueId();
        if (o.tur != Oda.Tur.PARKUR || !parkurUyarildi.contains(u) || parkurBitirdi.contains(u)) return;
        Location son = guvenli(new Location(w, o.x0 + o.len - 3 + 0.5, o.oy, o.oz + 0.5, -90f, 0f));
        p.teleport(son);
        p.setFallDistance(0);
        parkurBitirdi.add(u);
        ZindanSistemi.msj(p, "§aParkurun sonuna ışınlandın. §7Devam edebilirsin!");
    }

    private void parkurKontrol(Oda o, List<Player> aktif) {
        for (Player p : aktif) {
            Location l = p.getLocation();
            if (!o.icinde(l) && l.getY() > o.oy - 3) continue;
            // lava/boşluğa düşen (parkur bitmiş olsa bile) herkes parkurun başına döner
            if (l.getY() < o.oy - 5.2 && l.getX() >= o.x0 - 1 && l.getX() <= o.x0 + o.len + 1) {
                int n = dusme.merge(p.getUniqueId(), 1, Integer::sum);
                p.setFallDistance(0);
                p.setFireTicks(0);
                p.teleport(o.giris(w));
                ZindanSistemi.msj(p, "§cDüştün! §7Parkurun başına döndün. (" + n + ")");
                p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                continue;
            }
            // çatlak derin kayrak karo: üstüne basınca kısa süre sonra çöker, sonra geri gelir
            org.bukkit.block.Block ust = null;
            for (double[] of : new double[][]{{0, 0}, {0.3, 0.3}, {-0.3, 0.3}, {0.3, -0.3}, {-0.3, -0.3}}) {
                org.bukkit.block.Block bb = l.clone().add(of[0], -0.2, of[1]).getBlock();
                if (bb.getType() == Material.CRACKED_DEEPSLATE_TILES) {
                    ust = bb;
                    break;
                }
            }
            if (ust != null && p.isOnGround()) {
                final org.bukkit.block.Block ustF = ust;
                final long key = ((long) ustF.getX() << 38) ^ ((long) (ustF.getZ() & 0x3FFFFFF) << 12) ^ (ustF.getY() & 0xFFF);
                if (kirilanlar.add(key)) {
                    w.playSound(ustF.getLocation(), Sound.BLOCK_DEEPSLATE_TILES_BREAK, 1f, 0.7f);
                    Bukkit.getScheduler().runTaskLater(pl, () -> {
                        if (durum == Durum.BITIYOR) return;
                        ustF.setType(Material.AIR, false);
                        w.spawnParticle(Particle.BLOCK, ustF.getLocation().add(0.5, 0.5, 0.5), 20, 0.3, 0.2, 0.3,
                                Material.DEEPSLATE_TILES.createBlockData());
                    }, 10L);
                    Bukkit.getScheduler().runTaskLater(pl, () -> {
                        kirilanlar.remove(key);
                        if (durum == Durum.BITIYOR) return;
                        ustF.setType(Material.CRACKED_DEEPSLATE_TILES, false);
                    }, 90L);
                }
            }
        }
        if (!temiz[o.index]) {
            for (Player p : aktif) {
                if (o.bitisBolgesi(p.getLocation())) {
                    ZindanSistemi.msj(p, "§a" + p.getName() + " parkuru bitirdi!");
                    odaTemiz(o.index);
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------ yaratık yetenekleri

    private void atSaldirisi(SkeletonHorse at, MobBilgi b) {
        Player p = enYakin(at.getLocation(), 40);
        if (p == null) return;
        at.getPathfinder().moveTo(p.getLocation(), 1.7);
        b.sayac -= 5;
        if (b.sayac <= 0 && p.getLocation().distanceSquared(at.getLocation()) < 3.2 * 3.2) {
            b.sayac = 20;
            p.damage(pl.getConfig().getDouble("hasar.iskelet-at", 6.0) * z.hasar, at);
            Vector kb = p.getLocation().toVector().subtract(at.getLocation().toVector()).setY(0);
            if (kb.lengthSquared() > 0) p.setVelocity(p.getVelocity().add(kb.normalize().multiply(0.6).setY(0.3)));
            at.getWorld().playSound(at.getLocation(), Sound.ENTITY_HORSE_ANGRY, 1f, 0.6f);
        }
    }

    private void cadiIyilestir(Witch kendi, MobBilgi b) {
        b.sayac -= 20;
        if (b.sayac > 0) return;
        for (MobBilgi o : moblar.values()) {
            if (o == b || !o.anahtar.equals("cadi") || o.varlik == null || !o.varlik.isValid()) continue;
            if (o.canYuzde() >= 0.2) continue;
            if (o.varlik.getLocation().distanceSquared(kendi.getLocation()) > 30 * 30) continue;
            b.sayac = 100;
            fırlatIksir(kendi, o.varlik);
            return;
        }
    }

    private void fırlatIksir(Witch atan, LivingEntity hedef) {
        ItemStack it = new ItemStack(Material.SPLASH_POTION);
        PotionMeta pm = (PotionMeta) it.getItemMeta();
        pm.addCustomEffect(new PotionEffect(PotionEffectType.REGENERATION, 160, 2), true);
        it.setItemMeta(pm);
        Location from = atan.getEyeLocation();
        Vector v = hedef.getEyeLocation().toVector().subtract(from.toVector()).multiply(0.08).add(new Vector(0, 0.3, 0));
        atan.getWorld().spawn(from, ThrownPotion.class, tp -> {
            tp.setItem(it);
            tp.setShooter(atan);
            tp.setVelocity(v);
        });
        atan.getWorld().playSound(from, Sound.ENTITY_WITCH_THROW, 1f, 1f);
    }

    /** Mini boss Warden: herkese sonic patlaması atar ve 15 iskelet çağırır. */
    private void wardenSonik(Warden wd, MobBilgi b) {
        b.sayac -= 5;
        if (b.sayac > 0) return;
        b.sayac = 400 + (int) (200 * (1.0 - b.canYuzde()) * -1);   // can azaldıkça sıklaşır
        double hasar = pl.getConfig().getDouble("hasar.sonik-patlama", 10.0) * z.hasar;
        Location k = wd.getEyeLocation();
        wd.getWorld().playSound(k, Sound.ENTITY_WARDEN_SONIC_CHARGE, 3f, 1f);
        Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (!wd.isValid()) return;
            wd.getWorld().playSound(wd.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 3f, 1f);
            for (Player p : aktifOyuncular()) {
                Vector yon = p.getEyeLocation().toVector().subtract(wd.getEyeLocation().toVector());
                double mesafe = yon.length();
                yon.normalize();
                for (double d = 1; d < mesafe; d += 1.0) {
                    Location pt = wd.getEyeLocation().add(yon.clone().multiply(d));
                    w.spawnParticle(Particle.SONIC_BOOM, pt, 1, 0, 0, 0, 0);
                }
                p.damage(hasar, wd);
            }
            // iskeletleri çağır (en çok 30 canlı)
            long mevcut = moblar.values().stream().filter(m -> m.anahtar.equals("iskelet") && m.varlik != null && m.varlik.isValid()).count();
            int adet = (int) Math.min(15, Math.max(0, 30 - mevcut));
            Oda o = odalar.get(b.oda);
            for (int i = 0; i < adet; i++) {
                minyon(Skeleton.class, nokta(o), "iskelet", 40, s -> s.getEquipment().setItemInMainHand(new ItemStack(Material.BOW)));
            }
            if (adet > 0) herkeseMesaj("§3Zindan Muhafızı sonic patlaması attı ve iskeletleri çağırdı!");
        }, 30L);
    }

    // ================================================================== sanal can

    public void sanalCanYansit(MobBilgi b) {
        LivingEntity e = b.varlik;
        if (e == null || !e.isValid()) return;
        double oran = Math.max(0.0, b.vhp / b.vmax);
        e.setHealth(Math.max(1.0, Math.min(100.0, 100.0 * oran)));
    }

    // ================================================================== oyuncu çıkışı / bitiş

    public void cikar(Player p, String neden) {
        uyeler.remove(p.getUniqueId());
        pl.oyuncuInstance.remove(p.getUniqueId());
        if (zamanBar != null) zamanBar.removePlayer(p);
        for (MobBilgi b : moblar.values()) if (b.bar != null) b.bar.removePlayer(p);
        geriGonder(p);
        if (neden != null) ZindanSistemi.msj(p, neden);
        if (uyeler.isEmpty() && durum != Durum.BITIYOR) bitir("Herkes ayrıldı.");
    }

    /** Oyuncunun açılmamış/yarım kalmış sandık içeriklerini ganimet çantasına taşır (eşya kaybolmasın). */
    private void sandiklariCantaya(UUID u) {
        List<ItemStack> toplam = new ArrayList<>();
        for (Map<UUID, Inventory> m : sandikEnv.values()) {
            Inventory inv = m.get(u);
            if (inv == null) continue;
            for (ItemStack it : inv.getContents()) if (it != null && it.getType() != Material.AIR) toplam.add(it.clone());
            inv.clear();
        }
        if (!toplam.isEmpty()) pl.veri.bekleyenEkle(u, toplam);
    }

    public void geriGonder(Player p) {
        p.closeInventory();
        sandiklariCantaya(p.getUniqueId());
        Location d = donus.get(p.getUniqueId());
        if (d == null) d = pl.veri.donus(p.getUniqueId());
        if (d == null || d.getWorld() == null) d = Bukkit.getWorlds().get(0).getSpawnLocation();
        p.setFallDistance(0);
        p.teleport(d);
        pl.veri.donusSil(p.getUniqueId());
        // dünya değişimindeki envanter koruması/değişimi bitsin, sonra teslim et (3 sn); kapanışta çanta girişte verilir
        if (pl.isEnabled()) {
            Bukkit.getScheduler().runTaskLater(pl, () -> {
                if (p.isOnline() && !pl.oyuncuInstance.containsKey(p.getUniqueId())) pl.teslim(p);
            }, 60L);
        }
    }

    public void bitir(String neden) {
        if (durum == Durum.BITIYOR) return;
        durum = Durum.BITIYOR;
        if (gorev != null) gorev.cancel();
        herkeseMesaj("§e" + neden);
        for (UUID id : new ArrayList<>(moblar.keySet())) {
            MobBilgi b = moblar.get(id);
            if (b != null && b.bar != null) b.bar.removeAll();
            Entity e = Bukkit.getEntity(id);
            if (e != null) e.remove();
            pl.tumMoblar.remove(id);
        }
        moblar.clear();
        if (asmadeus != null) asmadeus.kaldir();
        for (MiniOverlord m : overlordlar) m.kaldir();
        if (zamanBar != null) zamanBar.removeAll();
        for (UUID u : new ArrayList<>(uyeler)) {
            Player p = Bukkit.getPlayer(u);
            pl.oyuncuInstance.remove(u);
            if (p != null && p.isOnline()) {
                geriGonder(p);
            } else {
                sandiklariCantaya(u);     // çevrimdışı: girince verilir
            }
        }
        uyeler.clear();
        // yapıyı temizle
        List<Yapi.Kutu> hava = new ArrayList<>();
        for (Yapi.Kutu k : kutular) hava.add(Yapi.hava(k));
        hava.addAll(sandikKutulari);
        temizlikte = true;
        isle(hava, () -> {
            for (Entity e : w.getEntities()) {
                if (e.getScoreboardTags().contains("zd") || e.getScoreboardTags().contains("zd_parca")) {
                    Location l = e.getLocation();
                    if (l.getX() >= ox - 50 && l.getX() <= ox + 450) e.remove();
                }
            }
            for (long k : biletler) w.removePluginChunkTicket((int) (k >> 32), (int) k, pl);
            biletler.clear();
            pl.slotBosalt(slot);
            pl.instances.remove(id);
        });
    }
}
