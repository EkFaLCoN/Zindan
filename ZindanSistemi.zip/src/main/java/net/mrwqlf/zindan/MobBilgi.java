package net.mrwqlf.zindan;

import org.bukkit.boss.BossBar;
import org.bukkit.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Bir zindan yaratığının kaydı. Can 900'ü aşarsa "sanal can" kullanılır (vanilla sınırı 1024). */
public final class MobBilgi {
    public final Instance inst;
    public final String anahtar;     // drop tablosu anahtarı
    public final String ad;
    public final boolean boss;       // true: çöp havuzundan yalnızca Kadim %1
    public final boolean olcekHasar; // true: vanilla vuruşlar zorluk hasar çarpanıyla çarpılır
    public final boolean odulVer;    // false: minyon (drop vermez)
    public final int oda;
    public boolean sanal;
    public double vmax;
    public double vhp;
    public BossBar bar;
    public int sayac;                // yeteneklere/zamanlayıcılara ait genel sayaç
    public final Map<UUID, Double> hasar = new HashMap<>();
    public LivingEntity varlik;

    public MobBilgi(Instance inst, String anahtar, String ad, boolean boss, boolean olcekHasar, boolean odulVer, int oda) {
        this.inst = inst;
        this.anahtar = anahtar;
        this.ad = ad;
        this.boss = boss;
        this.olcekHasar = olcekHasar;
        this.odulVer = odulVer;
        this.oda = oda;
    }

    public double canYuzde() {
        if (sanal) return Math.max(0.0, vhp / vmax);
        if (varlik == null || varlik.isDead()) return 0.0;
        var a = varlik.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
        double max = a == null ? 20.0 : a.getValue();
        return Math.max(0.0, Math.min(1.0, varlik.getHealth() / max));
    }
}
