package net.mrwqlf.zindan;

import org.bukkit.Location;
import org.bukkit.World;

import java.util.Random;

/** Bir zindan odasının geometrisi. Oda X ekseni boyunca uzanır; girişi batıda (x0), çıkışı doğudadır. */
public final class Oda {
    public enum Tur { SAVAS, PARKUR, BOSS }

    public final int index;
    public final Tur tur;
    public final int x0;      // iç alanın ilk x'i
    public final int len;     // iç alan uzunluğu (x)
    public final int hw;      // yarı genişlik: z in [oz-hw, oz+hw]
    public final int h;       // iç yükseklik
    public final int oy;      // zemin üstü ilk iç blok y'si
    public final int oz;
    public final boolean son;

    public Oda(int index, Tur tur, int x0, int len, int hw, int h, int oy, int oz, boolean son) {
        this.index = index;
        this.tur = tur;
        this.x0 = x0;
        this.len = len;
        this.hw = hw;
        this.h = h;
        this.oy = oy;
        this.oz = oz;
        this.son = son;
    }

    public int xSon() {
        return x0 + len - 1;
    }

    /** Odanın giriş noktası (oyuncular burada doğar). */
    public Location giris(World w) {
        return new Location(w, x0 + 2.5, oy, oz + 0.5, -90f, 0f);
    }

    public Location merkez(World w) {
        return new Location(w, x0 + len / 2.0 + 0.5, oy, oz + 0.5);
    }

    /** Savaş alanında rastgele bir nokta (girişe çok yakın olmayan). */
    public Location rastgele(World w, Random r) {
        double x = x0 + 8 + r.nextDouble() * Math.max(1, len - 12);
        double z = oz + (r.nextDouble() * 2 - 1) * (hw - 2);
        return new Location(w, x, oy, z);
    }

    public boolean icinde(Location l) {
        return l.getX() >= x0 && l.getX() < x0 + len && Math.abs(l.getZ() - (oz + 0.5)) <= hw + 0.5
                && l.getY() >= oy - 10 && l.getY() <= oy + h + 2;
    }

    /** Parkur bitiş çizgisi. */
    public boolean bitisBolgesi(Location l) {
        return tur == Tur.PARKUR && l.getX() >= x0 + len - 5 && l.getY() >= oy - 2 && l.getX() < x0 + len;
    }

    /** Sandık blok konumları: {x,y,z}. */
    public int[][] sandikKonumlari() {
        if (tur == Tur.PARKUR) {
            int x = x0 + len - 2;
            return new int[][]{{x, oy, oz - 3}, {x, oy, oz}, {x, oy, oz + 3}};
        }
        int z = oz - hw;
        int cx = x0 + len / 2;
        return new int[][]{{cx - 3, oy, z}, {cx, oy, z}, {cx + 3, oy, z}};
    }

    /** Sandıkların baktığı yön (BlockFace adı). */
    public String sandikYonu() {
        return tur == Tur.PARKUR ? "WEST" : "SOUTH";
    }

    /** Çıkış kapısının (demir parmaklık) bulunduğu kutu: {x, y1, z1, y2, z2}. */
    public int[] kapi() {
        return new int[]{x0 + len, oy, oz - 2, oy + 3, oz + 2};
    }
}
