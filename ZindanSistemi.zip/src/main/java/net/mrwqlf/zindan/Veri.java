package net.mrwqlf.zindan;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.UUID;

/** Günlük giriş sayaçları ve oyuncuların dönüş konumları (data.yml). */
public final class Veri {
    private final ZindanSistemi pl;
    private final File dosya;
    private final YamlConfiguration yaml;

    public Veri(ZindanSistemi pl) {
        this.pl = pl;
        this.dosya = new File(pl.getDataFolder(), "data.yml");
        this.yaml = YamlConfiguration.loadConfiguration(dosya);
    }

    public void kaydet() {
        try {
            yaml.save(dosya);
        } catch (IOException e) {
            pl.getLogger().warning("data.yml yazılamadı: " + e.getMessage());
        }
    }

    private String bugun() {
        String zone = pl.getConfig().getString("saat-dilimi", "Europe/Istanbul");
        try {
            return LocalDate.now(ZoneId.of(zone)).toString();
        } catch (RuntimeException e) {
            return LocalDate.now().toString();
        }
    }

    /** Bugün kaç kez girdi. */
    public int kullanilan(UUID id, String tip) {
        String v = yaml.getString("gunluk." + id + "." + tip, "");
        String[] p = v.split(":");
        if (p.length == 2 && p[0].equals(bugun())) {
            try {
                return Integer.parseInt(p[1]);
            } catch (NumberFormatException ignored) {
                return 0;
            }
        }
        return 0;
    }

    public void arttir(UUID id, String tip) {
        yaml.set("gunluk." + id + "." + tip, bugun() + ":" + (kullanilan(id, tip) + 1));
        kaydet();
    }

    public void sifirla(UUID id) {
        yaml.set("gunluk." + id, null);
        kaydet();
    }

    public void donusKaydet(Player p, Location l) {
        if (l == null || l.getWorld() == null) return;
        String k = "donus." + p.getUniqueId();
        yaml.set(k + ".w", l.getWorld().getName());
        yaml.set(k + ".x", l.getX());
        yaml.set(k + ".y", l.getY());
        yaml.set(k + ".z", l.getZ());
        yaml.set(k + ".yaw", l.getYaw());
        yaml.set(k + ".pitch", l.getPitch());
        kaydet();
    }

    public Location donus(UUID id) {
        String k = "donus." + id;
        if (!yaml.contains(k)) return null;
        World w = Bukkit.getWorld(yaml.getString(k + ".w", ""));
        if (w == null) return null;
        return new Location(w, yaml.getDouble(k + ".x"), yaml.getDouble(k + ".y"), yaml.getDouble(k + ".z"),
                (float) yaml.getDouble(k + ".yaw"), (float) yaml.getDouble(k + ".pitch"));
    }

    public void donusSil(UUID id) {
        yaml.set("donus." + id, null);
        kaydet();
    }
}
