package net.mrwqlf.zindan;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.UUID;

/** Günlük giriş sayaçları ve oyuncuların dönüş konumları (data.yml). */
public final class Veri {
    private final ZindanSistemi pl;
    private final File dosya;
    private final YamlConfiguration yaml;

    public Veri(ZindanSistemi pl) {
        this.pl = pl;
        this.dosya = new File(pl.getDataFolder(), "data.yml");
        this.yaml = YamlConfiguration.loadConfiguration(dosya);
    }

    public void kaydet() {
        try {
            yaml.save(dosya);
        } catch (IOException e) {
            pl.getLogger().warning("data.yml yazılamadı: " + e.getMessage());
        }
    }

    private String bugun() {
        String zone = pl.getConfig().getString("saat-dilimi", "Europe/Istanbul");
        try {
            return LocalDate.now(ZoneId.of(zone)).toString();
        } catch (RuntimeException e) {
            return LocalDate.now().toString();
        }
    }

    /** Bugün kaç kez girdi. */
    public int kullanilan(UUID id, String tip) {
        String v = yaml.getString("gunluk." + id + "." + tip, "");
        String[] p = v.split(":");
        if (p.length == 2 && p[0].equals(bugun())) {
            try {
                return Integer.parseInt(p[1]);
            } catch (NumberFormatException ignored) {
                return 0;
            }
        }
        return 0;
    }

    public void arttir(UUID id, String tip) {
        yaml.set("gunluk." + id + "." + tip, bugun() + ":" + (kullanilan(id, tip) + 1));
        kaydet();
    }

    public void sifirla(UUID id) {
        yaml.set("gunluk." + id, null);
        kaydet();
    }

    public void donusKaydet(Player p, Location l) {
        if (l == null || l.getWorld() == null) return;
        String k = "donus." + p.getUniqueId();
        yaml.set(k + ".w", l.getWorld().getName());
        yaml.set(k + ".x", l.getX());
        yaml.set(k + ".y", l.getY());
        yaml.set(k + ".z", l.getZ());
        yaml.set(k + ".yaw", l.getYaw());
        yaml.set(k + ".pitch", l.getPitch());
        kaydet();
    }

    public Location donus(UUID id) {
        String k = "donus." + id;
        if (!yaml.contains(k)) return null;
        World w = Bukkit.getWorld(yaml.getString(k + ".w", ""));
        if (w == null) return null;
        return new Location(w, yaml.getDouble(k + ".x"), yaml.getDouble(k + ".y"), yaml.getDouble(k + ".z"),
                (float) yaml.getDouble(k + ".yaw"), (float) yaml.getDouble(k + ".pitch"));
    }

    // ---- ganimet çantası: zindandan çıkışta teslim edilecek eşyalar
    public void bekleyenEkle(UUID id, java.util.List<org.bukkit.inventory.ItemStack> l) {
        java.util.List<String> kayit = new java.util.ArrayList<>(yaml.getStringList("bekleyen." + id));
        for (org.bukkit.inventory.ItemStack it : l) {
            if (it == null || it.getType().isAir()) continue;
            kayit.add(java.util.Base64.getEncoder().encodeToString(it.serializeAsBytes()));
        }
        yaml.set("bekleyen." + id, kayit);
        kaydet();
    }

    public boolean bekleyenVar(UUID id) {
        return !yaml.getStringList("bekleyen." + id).isEmpty();
    }

    /** Bekleyen eşyaları döndürür ve çantayı boşaltır. */
    public java.util.List<org.bukkit.inventory.ItemStack> bekleyenAl(UUID id) {
        java.util.List<org.bukkit.inventory.ItemStack> sonuc = new java.util.ArrayList<>();
        for (String s : yaml.getStringList("bekleyen." + id)) {
            try {
                sonuc.add(org.bukkit.inventory.ItemStack.deserializeBytes(java.util.Base64.getDecoder().decode(s)));
            } catch (RuntimeException e) {
                pl.getLogger().warning("Ganimet çantası kaydı okunamadı: " + e.getMessage());
            }
        }
        if (yaml.contains("bekleyen." + id)) {
            yaml.set("bekleyen." + id, null);
            kaydet();
        }
        return sonuc;
    }

    public void donusSil(UUID id) {
        yaml.set("donus." + id, null);
        kaydet();
    }
}
