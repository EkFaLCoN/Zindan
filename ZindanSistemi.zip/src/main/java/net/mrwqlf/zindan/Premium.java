package net.mrwqlf.zindan;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/**
 * Drop Premium: bitiş zamanı oyuncunun PDC'sinde (zindan:drop_premium, epoch ms) durur.
 * CursedValleyMobsAndMobs aynı anahtarı okuyarak vadi yaratıklarında da çarpanı uygular.
 */
public final class Premium {
    public static final NamespacedKey BITIS = new NamespacedKey("zindan", "drop_premium");
    public static final NamespacedKey KART = new NamespacedKey("zindan", "premium_karti");
    public static final long GUN_MS = 24L * 60 * 60 * 1000;

    private Premium() {
    }

    public static long bitis(Player p) {
        Long v = p.getPersistentDataContainer().get(BITIS, PersistentDataType.LONG);
        return v == null ? 0L : v;
    }

    public static boolean aktif(Player p) {
        return bitis(p) > System.currentTimeMillis();
    }

    /** Premium varsa 2.0 (yüzde yüz artış), yoksa 1.0. */
    public static double carpan(Player p) {
        return p != null && aktif(p) ? 2.0 : 1.0;
    }

    /** Süreyi uzatır; aktifse mevcut bitişin üstüne ekler. */
    public static long gunEkle(Player p, int gun) {
        long simdi = System.currentTimeMillis();
        long taban = Math.max(simdi, bitis(p));
        long yeni = taban + gun * GUN_MS;
        p.getPersistentDataContainer().set(BITIS, PersistentDataType.LONG, yeni);
        return yeni;
    }

    public static String kalan(Player p) {
        long ms = bitis(p) - System.currentTimeMillis();
        if (ms <= 0) return "yok";
        long gun = ms / GUN_MS;
        long saat = (ms % GUN_MS) / 3_600_000L;
        return gun + " gün " + saat + " saat";
    }

    public static ItemStack kartYap(int adet, int gun) {
        ItemStack it = new ItemStack(Material.PAPER, Math.max(1, adet));
        ItemMeta m = it.getItemMeta();
        m.setDisplayName("§6§lDrop Premium Kartı §7(" + gun + " gün)");
        m.setLore(List.of(
                "§7Sağ tık: Drop Premium'u etkinleştirir.",
                "§e" + gun + " gün boyunca tüm yaratık ve boss",
                "§edroplarının düşme şansı §l%100 artar§e.",
                "§e+ Solo zindana günde 2 kez girme hakkı.",
                "§8(Cursed Valley + Zindanlar; örn. %0.001 → %0.002)"));
        m.setEnchantmentGlintOverride(true);
        m.getPersistentDataContainer().set(KART, PersistentDataType.INTEGER, gun);
        it.setItemMeta(m);
        return it;
    }

    public static int kartGunu(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return 0;
        Integer g = it.getItemMeta().getPersistentDataContainer().get(KART, PersistentDataType.INTEGER);
        return g == null ? 0 : g;
    }
}
