package net.mrwqlf.zindan;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public final class ZindanSistemi extends JavaPlugin {
    public static final String SOLO_DUNYA = "zindan_solo";
    public static final String PARTI_DUNYA = "zindan_parti";
    public static final NamespacedKey NPC_ANAHTAR = new NamespacedKey("zindan", "npc");

    public Veri veri;
    public Loot loot;
    World soloDunya, partiDunya;
    final Map<String, Instance> instances = new HashMap<>();
    public final Map<UUID, Instance> oyuncuInstance = new HashMap<>();
    public final Map<UUID, MobBilgi> tumMoblar = new HashMap<>();
    private final boolean[] slotKullanim = new boolean[16];

    /** Boş (void) dünya üreteci. */
    public static final class BosUretec extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World world, Random random) {
            return new Location(world, 0.5, 100, 0.5);
        }
    }

    public static final class Menu implements InventoryHolder {
        public final String tip;
        private Inventory inv;

        Menu(String tip) {
            this.tip = tip;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Zorluk.yukle(getConfig());
        veri = new Veri(this);
        loot = new Loot(this);
        soloDunya = dunyaKur(SOLO_DUNYA);
        partiDunya = dunyaKur(PARTI_DUNYA);
        Bukkit.getPluginManager().registerEvents(new Dinleyici(this), this);
        var cmd = getCommand("zindan");
        if (cmd != null) {
            cmd.setExecutor(this::komutIsle);
            cmd.setTabCompleter(this::tab);
        }
        // DropByDrop sonradan yüklenebilir
        Bukkit.getScheduler().runTaskLater(this, () -> {
            int n = loot.copYukle();
            getLogger().info(n >= 0 ? "Çöp havuzu: " + n + " eşya (DropByDrop)" : "DropByDrop bulunamadı; çöp droplar kapalı.");
        }, 40L);
        // eski kalıntıları temizle
        Bukkit.getScheduler().runTaskLater(this, () -> {
            for (World w : new World[]{soloDunya, partiDunya}) {
                if (w == null) continue;
                for (org.bukkit.entity.Entity e : w.getEntities()) {
                    if (e.getScoreboardTags().contains("zd") || e.getScoreboardTags().contains("zd_parca")) e.remove();
                }
            }
        }, 20L);
        getLogger().info("ZindanSistemi etkin.");
    }

    @Override
    public void onDisable() {
        for (Instance in : new ArrayList<>(instances.values())) {
            for (UUID u : new ArrayList<>(in.uyeler)) {
                Player p = Bukkit.getPlayer(u);
                if (p != null) in.geriGonder(p);
            }
            if (in.zamanBar != null) in.zamanBar.removeAll();
            if (in.asmadeus != null) in.asmadeus.kaldir();
            for (MiniOverlord m : in.overlordlar) m.kaldir();
            for (UUID id : in.moblar.keySet()) {
                org.bukkit.entity.Entity e = Bukkit.getEntity(id);
                if (e != null) e.remove();
            }
        }
        if (veri != null) veri.kaydet();
    }

    private World dunyaKur(String ad) {
        World w = Bukkit.getWorld(ad);
        if (w == null) {
            WorldCreator wc = new WorldCreator(ad);
            wc.generator(new BosUretec());
            wc.environment(World.Environment.NORMAL);
            wc.generateStructures(false);
            w = wc.createWorld();
        }
        if (w != null) {
            w.setDifficulty(Difficulty.HARD);
            w.setTime(18000);
            w.setStorm(false);
            w.setAutoSave(false);
        }
        return w;
    }

    public static void msj(CommandSender p, String s) {
        p.sendMessage(LegacyComponentSerializer.legacySection().deserialize("§8[§5Zindan§8] §r" + s));
    }

    // ================================================================== slotlar

    private int slotBul(boolean parti) {
        int bas = parti ? 8 : 0;
        for (int i = bas; i < bas + 8; i++) {
            if (!slotKullanim[i]) {
                slotKullanim[i] = true;
                return i;
            }
        }
        return -1;
    }

    void slotBosalt(int slot) {
        if (slot >= 0 && slot < slotKullanim.length) slotKullanim[slot] = false;
    }

    // ================================================================== parti köprüsü

    private Plugin partiEklentisi() {
        Plugin p = Bukkit.getPluginManager().getPlugin("PartySistemi");
        return p != null && p.isEnabled() ? p : null;
    }

    private UUID partiLideri(UUID u) {
        try {
            Plugin p = partiEklentisi();
            if (p == null) return null;
            Method m = p.getClass().getMethod("getLeaderOf", UUID.class);
            return (UUID) m.invoke(p, u);
        } catch (ReflectiveOperationException | RuntimeException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private List<UUID> partiUyeleri(UUID u) {
        try {
            Plugin p = partiEklentisi();
            if (p == null) return List.of();
            Method m = p.getClass().getMethod("getMembersOf", UUID.class);
            return (List<UUID>) m.invoke(p, u);
        } catch (ReflectiveOperationException | RuntimeException e) {
            return List.of();
        }
    }

    // ================================================================== giriş

    public void girisDene(Player p, String tip, Zorluk z, boolean deneme) {
        boolean parti = tip.equals("parti");
        if (oyuncuInstance.containsKey(p.getUniqueId())) {
            msj(p, "§cZaten bir zindandasın. Çıkmak için §f/zindan cik");
            return;
        }
        List<Player> girecek = new ArrayList<>();
        String sayacTip = parti ? "parti" : "solo";
        int max = getConfig().getInt(parti ? "gunluk.parti" : "gunluk.solo", parti ? 1 : 2);

        if (!parti) {
            if (!deneme && veri.kullanilan(p.getUniqueId(), sayacTip) >= max) {
                msj(p, "§cBugünkü solo zindan hakkın bitti (§f" + max + "§c/gün). Yarın tekrar gel!");
                return;
            }
            girecek.add(p);
        } else if (deneme) {
            girecek.add(p);
        } else {
            UUID lider = partiLideri(p.getUniqueId());
            if (lider == null) {
                msj(p, "§cBir partide değilsin. Parti zindanı için tam dolu bir parti gerekir.");
                return;
            }
            if (!lider.equals(p.getUniqueId())) {
                msj(p, "§cParti zindanına yalnızca §eparti lideri §cgirebilir; herkesi o götürür.");
                return;
            }
            int gerekli = getConfig().getInt("parti-boyutu", 8);
            List<UUID> uyeler = partiUyeleri(p.getUniqueId());
            if (uyeler.size() != gerekli) {
                msj(p, "§cParti zindanı için partide tam §e" + gerekli + " §ckişi olmalı (şu an " + uyeler.size() + ").");
                return;
            }
            List<String> sorun = new ArrayList<>();
            for (UUID u : uyeler) {
                Player m = Bukkit.getPlayer(u);
                if (m == null || !m.isOnline()) {
                    sorun.add("§7" + Bukkit.getOfflinePlayer(u).getName() + " §c(çevrimdışı)");
                    continue;
                }
                if (oyuncuInstance.containsKey(u)) sorun.add("§7" + m.getName() + " §c(zaten zindanda)");
                else if (veri.kullanilan(u, sayacTip) >= max) sorun.add("§7" + m.getName() + " §c(bugünkü hakkı bitti)");
                else girecek.add(m);
            }
            if (!sorun.isEmpty()) {
                msj(p, "§cGirilemiyor: " + String.join("§c, ", sorun));
                return;
            }
        }

        int slot = slotBul(parti);
        if (slot < 0) {
            msj(p, "§cŞu an tüm zindanlar dolu, birazdan tekrar dene.");
            return;
        }
        World w = parti ? partiDunya : soloDunya;
        if (w == null) {
            slotBosalt(slot);
            msj(p, "§cZindan dünyası yüklenemedi (konsolu kontrol et).");
            return;
        }
        if (!deneme) for (Player g : girecek) veri.arttir(g.getUniqueId(), sayacTip);
        String id = UUID.randomUUID().toString().substring(0, 8);
        Instance in = new Instance(this, id, parti, z, w, slot, deneme);
        instances.put(id, in);
        in.baslat(girecek);
    }

    // ================================================================== NPC ve menü

    public void menuAc(Player p, String tip) {
        boolean parti = tip.equals("parti");
        Menu holder = new Menu(tip);
        Inventory inv = Bukkit.createInventory(holder, 27, parti ? "§5Parti Zindanı" : "§5Solo Zindan");
        holder.inv = inv;
        int max = getConfig().getInt(parti ? "gunluk.parti" : "gunluk.solo", parti ? 1 : 2);
        int kalan = Math.max(0, max - veri.kullanilan(p.getUniqueId(), parti ? "parti" : "solo"));
        int[] yer = {10, 12, 14, 16};
        Zorluk[] zs = Zorluk.values();
        for (int i = 0; i < 4; i++) {
            Zorluk z = zs[i];
            ItemStack it = new ItemStack(z.simge);
            ItemMeta m = it.getItemMeta();
            m.setDisplayName(z.renk + "§l" + z.ad);
            List<String> l = new ArrayList<>();
            l.add("§7Yaratık canı: §f×" + z.hp);
            l.add("§7Yaratık hasarı: §f×" + z.hasar);
            if (z.sayi != 1.0) l.add("§7Yaratık sayısı: §f×" + z.sayi);
            l.add("§7Drop şansı: §a×" + z.drop);
            l.add(z.yenilenme > 0 ? "§7Boss can yenilemesi: §cvar" : "§7Boss can yenilemesi: §ayok");
            l.add("");
            l.add("§eTıkla ve zindana gir!");
            m.setLore(l);
            it.setItemMeta(m);
            inv.setItem(yer[i], it);
        }
        ItemStack bilgi = new ItemStack(Material.BOOK);
        ItemMeta bm = bilgi.getItemMeta();
        bm.setDisplayName("§6Bilgi");
        List<String> bl = new ArrayList<>();
        if (parti) {
            bl.add("§7• Yalnızca §eparti lideri §7girebilir");
            bl.add("§7• Partide tam §e" + getConfig().getInt("parti-boyutu", 8) + " §7kişi gerekir");
            bl.add("§7• Günde §e1 §7kez (kişi başı)");
            bl.add("§7• 6 oda, ana boss: §5ASMADEUS");
        } else {
            bl.add("§7• Tek başına girilir");
            bl.add("§7• Günde §e" + max + " §7kez");
            bl.add("§7• 7 oda, son boss: §dMini Overlord");
        }
        bl.add("§7• Süre: §e" + getConfig().getInt("sure-dakika", 60) + " dakika");
        bl.add("§7• Ölünce eşya düşmez, ganimet sana aittir");
        bl.add("");
        bl.add("§aBugünkü kalan hakkın: §f" + kalan);
        if (Premium.aktif(p)) bl.add("§6Drop Premium: §f" + Premium.kalan(p));
        bm.setLore(bl);
        bilgi.setItemMeta(bm);
        inv.setItem(22, bilgi);
        p.openInventory(inv);
    }

    private void npcYarat(Player p, String tip) {
        boolean parti = tip.equals("parti");
        Location l = p.getLocation();
        Villager v = p.getWorld().spawn(l, Villager.class, e -> {
            e.setAI(false);
            e.setInvulnerable(true);
            e.setSilent(true);
            e.setPersistent(true);
            e.setRemoveWhenFarAway(false);
            e.setProfession(Villager.Profession.CLERIC);
            e.customName(LegacyComponentSerializer.legacySection().deserialize(parti ? "§5§lParti Zindanı §7- Bekçi" : "§5§lSolo Zindan §7- Bekçi"));
            e.setCustomNameVisible(true);
            e.getPersistentDataContainer().set(NPC_ANAHTAR, PersistentDataType.STRING, tip);
        });
        v.teleport(l);
        msj(p, "§a" + (parti ? "Parti" : "Solo") + " zindan NPC'si yerleştirildi. Silmek için üstüne bakıp §f/zindan npcsil");
    }

    // ================================================================== komutlar

    private boolean komutIsle(CommandSender s, Command c, String label, String[] a) {
        String alt = a.length > 0 ? a[0].toLowerCase() : "bilgi";
        boolean admin = s.hasPermission("zindan.admin");
        switch (alt) {
            case "bilgi" -> {
                if (!(s instanceof Player p)) return true;
                int ms = getConfig().getInt("gunluk.solo", 2), mp = getConfig().getInt("gunluk.parti", 1);
                msj(p, "§7Solo kalan hak: §f" + Math.max(0, ms - veri.kullanilan(p.getUniqueId(), "solo")) + "/" + ms
                        + " §8| §7Parti kalan hak: §f" + Math.max(0, mp - veri.kullanilan(p.getUniqueId(), "parti")) + "/" + mp);
                msj(p, "§6Drop Premium: §f" + Premium.kalan(p));
            }
            case "cik" -> {
                if (!(s instanceof Player p)) return true;
                Instance in = oyuncuInstance.get(p.getUniqueId());
                if (in == null) {
                    msj(p, "§7Bir zindanda değilsin.");
                    return true;
                }
                in.cikar(p, "§eZindandan ayrıldın.");
            }
            case "premium" -> premiumKomut(s, a, admin);
            case "npc" -> {
                if (!admin || !(s instanceof Player p)) return true;
                if (a.length < 2 || !(a[1].equalsIgnoreCase("solo") || a[1].equalsIgnoreCase("parti"))) {
                    msj(s, "§c/zindan npc <solo|parti>");
                    return true;
                }
                npcYarat(p, a[1].toLowerCase());
            }
            case "npcsil" -> {
                if (!admin || !(s instanceof Player p)) return true;
                var hedef = p.getTargetEntity(6);
                if (hedef != null && hedef.getPersistentDataContainer().has(NPC_ANAHTAR, PersistentDataType.STRING)) {
                    hedef.remove();
                    msj(p, "§aNPC silindi.");
                } else msj(p, "§cBir zindan NPC'sine bak.");
            }
            case "test", "deneme" -> {
                if (!admin || !(s instanceof Player p)) {
                    msj(s, "§cBu komut yalnızca yetkili oyuncular içindir.");
                    return true;
                }
                if (a.length < 2 || !(a[1].equalsIgnoreCase("solo") || a[1].equalsIgnoreCase("parti"))) {
                    msj(s, "§c/zindan test <solo|parti> [kolay|normal|zor|olumcul]");
                    return true;
                }
                Zorluk z = a.length >= 3 ? Zorluk.bul(a[2]) : Zorluk.KOLAY;
                if (z == null) {
                    msj(s, "§cZorluk: kolay, normal, zor, olumcul");
                    return true;
                }
                girisDene(p, a[1].toLowerCase(), z, true);
            }
            case "bitir" -> {
                if (!admin || !(s instanceof Player p)) return true;
                Instance in = oyuncuInstance.get(p.getUniqueId());
                if (in == null) {
                    msj(s, "§7Bir zindanda değilsin.");
                    return true;
                }
                in.bitir("Zindan yönetici tarafından sonlandırıldı.");
            }
            case "sifirla" -> {
                if (!admin) return true;
                if (a.length < 2) {
                    msj(s, "§c/zindan sifirla <oyuncu>");
                    return true;
                }
                @SuppressWarnings("deprecation")
                var op = Bukkit.getOfflinePlayer(a[1]);
                veri.sifirla(op.getUniqueId());
                msj(s, "§a" + a[1] + " için günlük giriş hakları sıfırlandı.");
            }
            case "model" -> {
                if (!admin || !(s instanceof Player p)) return true;
                String v = a.length >= 2 ? a[1] : getConfig().getString("asmadeus.model-varyanti", "a");
                Location l = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(8));
                List<ItemDisplay> liste = AsmadeusBoss.vitrin(p.getWorld(), l, getConfig().getDouble("asmadeus.olcek", 1.8), v);
                msj(p, "§aAsmadeus vitrini (varyant " + v + ") 30 sn görünecek. Ters/dağınık görünüyorsa §f/zindan model b §ayı dene.");
                Bukkit.getScheduler().runTaskLater(this, () -> liste.forEach(ItemDisplay::remove), 600L);
            }
            case "reload" -> {
                if (!admin) return true;
                reloadConfig();
                Zorluk.yukle(getConfig());
                loot.yukle();
                int n = loot.copYukle();
                msj(s, "§aYeniden yüklendi. Çöp havuzu: " + n);
            }
            case "drop" -> dropKomut(s, a, admin);
            default -> msj(s, "§7/zindan <bilgi|cik|premium" + (admin ? "|npc|npcsil|test|bitir|sifirla|model|drop|reload" : "") + ">");
        }
        return true;
    }

    private void premiumKomut(CommandSender s, String[] a, boolean admin) {
        if (a.length == 1) {
            if (s instanceof Player p) msj(p, "§6Drop Premium kalan süre: §f" + Premium.kalan(p));
            return;
        }
        if (!admin) return;
        String islem = a[1].toLowerCase();
        if (a.length < 3) {
            msj(s, "§c/zindan premium <ver|kart|al> <oyuncu> [gün|adet] [gün]");
            return;
        }
        Player hedef = Bukkit.getPlayerExact(a[2]);
        if (hedef == null) {
            msj(s, "§cOyuncu çevrimiçi değil.");
            return;
        }
        int sayi = 30;
        try {
            if (a.length >= 4) sayi = Integer.parseInt(a[3]);
        } catch (NumberFormatException e) {
            msj(s, "§cSayı gir.");
            return;
        }
        switch (islem) {
            case "ver" -> {
                Premium.gunEkle(hedef, sayi);
                msj(s, "§a" + hedef.getName() + " §7→ " + sayi + " gün Drop Premium eklendi.");
                msj(hedef, "§6Drop Premium §aetkinleştirildi! §7Kalan: §e" + Premium.kalan(hedef));
            }
            case "kart" -> {
                int gun = 30;
                try {
                    if (a.length >= 5) gun = Integer.parseInt(a[4]);
                } catch (NumberFormatException ignored) {
                    // 30
                }
                ItemStack k = Premium.kartYap(sayi, gun);
                hedef.getInventory().addItem(k).values().forEach(x -> hedef.getWorld().dropItem(hedef.getLocation(), x));
                msj(s, "§a" + hedef.getName() + " §7→ " + sayi + " adet Drop Premium kartı (" + gun + " gün) verildi.");
            }
            case "al" -> {
                hedef.getPersistentDataContainer().remove(Premium.BITIS);
                msj(s, "§a" + hedef.getName() + " Drop Premium'u kaldırıldı.");
            }
            default -> msj(s, "§c/zindan premium <ver|kart|al> <oyuncu> [gün|adet] [gün]");
        }
    }

    private static final List<String> MOB_ANAHTARLARI = List.of("tum",
            "evoker", "cadi", "kara_kurt", "iskelet_at", "iskelet_binici", "piglin_brute", "warden", "mini_overlord",
            "zombi", "wither_iskelet", "warden_mini", "ravager_mini", "piglin_binici", "bogged", "asmadeus");

    private void dropKomut(CommandSender s, String[] a, boolean admin) {
        if (!admin) return;
        if (a.length < 2) {
            msj(s, "§e/zindan drop ekle mob <anahtar|tum> <yüzde>");
            msj(s, "§e/zindan drop ekle sandik <solo|parti> <oda 1-7|hepsi> <yüzde>   §7(elindeki eşya eklenir)");
            msj(s, "§e/zindan drop liste [mob|sandik]  §8| §e/zindan drop sil <tablo> <no>  §8| §e/zindan drop anahtarlar");
            return;
        }
        switch (a[1].toLowerCase()) {
            case "anahtarlar" -> msj(s, "§7Mob anahtarları: §f" + String.join(", ", MOB_ANAHTARLARI)
                    + " §8| §7Sandık tabloları: §fsandik.solo.hepsi, sandik.solo.3, sandik.parti.hepsi ...");
            case "ekle" -> {
                if (!(s instanceof Player p)) return;
                ItemStack el = p.getInventory().getItemInMainHand();
                if (el.getType() == Material.AIR) {
                    msj(s, "§cElinde eşya olmalı.");
                    return;
                }
                String anahtar;
                double yuzde;
                try {
                    if (a.length >= 5 && a[2].equalsIgnoreCase("mob")) {
                        anahtar = "mob." + a[3].toLowerCase();
                        yuzde = Double.parseDouble(a[4].replace(',', '.').replace("%", ""));
                        if (!MOB_ANAHTARLARI.contains(a[3].toLowerCase())) {
                            msj(s, "§cBilinmeyen mob anahtarı. §7/zindan drop anahtarlar");
                            return;
                        }
                    } else if (a.length >= 6 && a[2].equalsIgnoreCase("sandik")) {
                        String tip = a[3].toLowerCase();
                        if (!tip.equals("solo") && !tip.equals("parti")) {
                            msj(s, "§cTip: solo veya parti");
                            return;
                        }
                        anahtar = "sandik." + tip + "." + a[4].toLowerCase();
                        yuzde = Double.parseDouble(a[5].replace(',', '.').replace("%", ""));
                    } else {
                        msj(s, "§c/zindan drop ekle mob <anahtar|tum> <yüzde>  veya  sandik <solo|parti> <oda|hepsi> <yüzde>");
                        return;
                    }
                } catch (NumberFormatException e) {
                    msj(s, "§cYüzde bir sayı olmalı (örn. 0.5).");
                    return;
                }
                loot.tablo(anahtar).add(new Loot.Giris(el.clone(), yuzde));
                loot.kaydet();
                msj(s, "§aEklendi: §f" + anahtar + " §7→ " + el.getAmount() + "x " + el.getType().name() + " §7(%" + yuzde + ")");
            }
            case "liste" -> {
                String filtre = a.length >= 3 ? a[2].toLowerCase() : "";
                int say = 0;
                for (var e : loot.hepsi().entrySet()) {
                    if (!filtre.isEmpty() && !e.getKey().startsWith(filtre)) continue;
                    msj(s, "§e" + e.getKey() + " §7(" + e.getValue().size() + ")");
                    int i = 1;
                    for (Loot.Giris g : e.getValue()) {
                        msj(s, "  §8" + (i++) + ". §f" + g.esya().getAmount() + "x " + g.esya().getType().name() + " §7%" + g.yuzde());
                        if (++say > 60) {
                            msj(s, "§7... (çok uzun, filtre kullan)");
                            return;
                        }
                    }
                }
                if (say == 0) msj(s, "§7Kayıt yok.");
            }
            case "sil" -> {
                if (a.length < 4) {
                    msj(s, "§c/zindan drop sil <tablo> <no>   örn: mob.asmadeus 1");
                    return;
                }
                var l = loot.tablo(a[2].toLowerCase());
                try {
                    int no = Integer.parseInt(a[3]);
                    if (no < 1 || no > l.size()) throw new NumberFormatException();
                    l.remove(no - 1);
                    loot.kaydet();
                    msj(s, "§aSilindi.");
                } catch (NumberFormatException e) {
                    msj(s, "§cGeçersiz numara.");
                }
            }
            default -> msj(s, "§c/zindan drop <ekle|liste|sil|anahtarlar>");
        }
    }

    private List<String> tab(CommandSender s, Command c, String l, String[] a) {
        boolean admin = s.hasPermission("zindan.admin");
        List<String> r = new ArrayList<>();
        if (a.length == 1) {
            r.addAll(List.of("bilgi", "cik", "premium"));
            if (admin) r.addAll(List.of("npc", "npcsil", "test", "bitir", "sifirla", "model", "drop", "reload"));
        } else if (a.length == 2 && admin) {
            switch (a[0].toLowerCase()) {
                case "npc", "test" -> r.addAll(List.of("solo", "parti"));
                case "premium" -> r.addAll(List.of("ver", "kart", "al"));
                case "model" -> r.addAll(List.of("a", "b"));
                case "drop" -> r.addAll(List.of("ekle", "liste", "sil", "anahtarlar"));
                default -> {
                }
            }
        } else if (a.length == 3 && admin) {
            if (a[0].equalsIgnoreCase("test")) r.addAll(List.of("kolay", "normal", "zor", "olumcul"));
            if (a[0].equalsIgnoreCase("drop") && a[1].equalsIgnoreCase("ekle")) r.addAll(List.of("mob", "sandik"));
        } else if (a.length == 4 && admin && a[0].equalsIgnoreCase("drop") && a[1].equalsIgnoreCase("ekle")) {
            if (a[2].equalsIgnoreCase("mob")) r.addAll(MOB_ANAHTARLARI);
            if (a[2].equalsIgnoreCase("sandik")) r.addAll(List.of("solo", "parti"));
        } else if (a.length == 5 && admin && a[0].equalsIgnoreCase("drop") && a[2].equalsIgnoreCase("sandik")) {
            r.addAll(List.of("hepsi", "1", "2", "3", "4", "5", "6", "7"));
        }
        String son = a.length > 0 ? a[a.length - 1].toLowerCase() : "";
        r.removeIf(x -> !x.toLowerCase().startsWith(son));
        return r;
    }
}
