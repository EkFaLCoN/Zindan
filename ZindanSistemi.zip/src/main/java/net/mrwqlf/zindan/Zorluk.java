package net.mrwqlf.zindan;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

/** Zindan zorlukları. Değerler config.yml > zorluk bölümünden okunur. */
public enum Zorluk {
    KOLAY("kolay", "Kolay", Material.LIME_WOOL, "§a", 1.0, 1.0, 1.0, 0.0, 1.0),
    NORMAL("normal", "Normal", Material.YELLOW_WOOL, "§e", 1.5, 1.25, 1.0, 0.0, 1.5),
    ZOR("zor", "Zor", Material.ORANGE_WOOL, "§6", 2.0, 1.6, 1.15, 0.0005, 2.0),
    OLUMCUL("olumcul", "Ölümcül", Material.RED_WOOL, "§c", 3.0, 2.2, 1.3, 0.001, 3.0);

    public final String id;
    public final String ad;
    public final Material simge;
    public final String renk;
    /** Can çarpanı. */
    public double hp;
    /** Hasar çarpanı. */
    public double hasar;
    /** Yaratık sayısı çarpanı. */
    public double sayi;
    /** Boss'un saniyede yenilediği can oranı (0 = yenilenme yok). */
    public double yenilenme;
    /** Drop şansı çarpanı (zorluk arttıkça artar). */
    public double drop;

    Zorluk(String id, String ad, Material simge, String renk, double hp, double hasar, double sayi, double yenilenme, double drop) {
        this.id = id;
        this.ad = ad;
        this.simge = simge;
        this.renk = renk;
        this.hp = hp;
        this.hasar = hasar;
        this.sayi = sayi;
        this.yenilenme = yenilenme;
        this.drop = drop;
    }

    public static void yukle(FileConfiguration c) {
        for (Zorluk z : values()) {
            String p = "zorluk." + z.id + ".";
            z.hp = c.getDouble(p + "can-carpani", z.hp);
            z.hasar = c.getDouble(p + "hasar-carpani", z.hasar);
            z.sayi = c.getDouble(p + "sayi-carpani", z.sayi);
            z.yenilenme = c.getDouble(p + "boss-yenilenme", z.yenilenme);
            z.drop = c.getDouble(p + "drop-carpani", z.drop);
        }
    }

    public static Zorluk bul(String s) {
        if (s == null) return null;
        String k = s.toLowerCase().replace('ö', 'o').replace('ü', 'u').replace('ı', 'i');
        for (Zorluk z : values()) {
            if (z.id.equals(k) || z.name().equalsIgnoreCase(k)) return z;
        }
        return null;
    }
}
