package net.mrwqlf.zindan;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EvokerFangs;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Warden;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;
import java.util.UUID;

public final class Dinleyici implements Listener {
    private final ZindanSistemi pl;

    public Dinleyici(ZindanSistemi pl) {
        this.pl = pl;
    }

    private boolean zindanDunyasi(org.bukkit.World w) {
        return w != null && (w.getName().equals(ZindanSistemi.SOLO_DUNYA) || w.getName().equals(ZindanSistemi.PARTI_DUNYA));
    }

    // ================================================================== hasar

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHasar(EntityDamageEvent e) {
        Entity kurban = e.getEntity();

        // 1) zindan yaratığına hasar -> sanal can + hasar takibi
        MobBilgi b = pl.tumMoblar.get(kurban.getUniqueId());
        if (b != null) {
            if (e instanceof EntityDamageByEntityEvent ee) {
                Player oy = oyuncuyaCevir(ee.getDamager());
                if (oy != null) {
                    if (!b.inst.uyeler.contains(oy.getUniqueId())) {
                        e.setCancelled(true);
                        return;
                    }
                    b.hasar.merge(oy.getUniqueId(), e.getFinalDamage(), Double::sum);
                }
            }
            if (b.sanal && kurban instanceof LivingEntity le) {
                double d = e.getFinalDamage();
                e.setDamage(0);
                b.vhp -= d;
                if (b.vhp <= 0) {
                    b.vhp = 0;
                    le.setHealth(0);
                } else {
                    b.inst.sanalCanYansit(b);
                }
            }
            return;
        }

        // 2) oyuncuya zindan yaratığı hasarı -> zorluk çarpanı
        if (kurban instanceof Player && e instanceof EntityDamageByEntityEvent ee) {
            Entity kaynak = ee.getDamager();
            if (kaynak instanceof Projectile pr && pr.getShooter() instanceof Entity sh) kaynak = sh;
            if (kaynak instanceof EvokerFangs ef && ef.getOwner() != null) kaynak = ef.getOwner();
            MobBilgi mb = pl.tumMoblar.get(kaynak.getUniqueId());
            if (mb != null && mb.olcekHasar) {
                if (kaynak instanceof Warden) {
                    e.setDamage(pl.getConfig().getDouble("hasar.warden", 30.0) * mb.inst.z.hasar);
                } else {
                    e.setDamage(e.getDamage() * mb.inst.z.hasar);
                }
            }
        }
    }

    private Player oyuncuyaCevir(Entity d) {
        if (d instanceof Player p) return p;
        if (d instanceof Projectile pr && pr.getShooter() instanceof Player p) return p;
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onOlum(EntityDeathEvent e) {
        MobBilgi b = pl.tumMoblar.get(e.getEntity().getUniqueId());
        if (b == null) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        b.inst.mobOldu(b, e.getEntity().getUniqueId(), e.getEntity().getKiller());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onOyuncuOlum(PlayerDeathEvent e) {
        Instance in = pl.oyuncuInstance.get(e.getEntity().getUniqueId());
        if (in == null) return;
        e.setKeepInventory(true);
        e.setKeepLevel(true);
        e.getDrops().clear();
        e.setDroppedExp(0);
    }

    @EventHandler
    public void onYenidenDogma(PlayerRespawnEvent e) {
        Instance in = pl.oyuncuInstance.get(e.getPlayer().getUniqueId());
        if (in == null || in.durum != Instance.Durum.CALISIYOR) return;
        e.setRespawnLocation(in.kontrolNoktasi());
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(pl, () -> {
            p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 3));
            ZindanSistemi.msj(p, "§eKontrol noktasında yeniden doğdun. §7Eşyaların korundu.");
        }, 2L);
    }

    // ================================================================== etkileşim

    @EventHandler
    public void onEtkilesim(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (e.getHand() != EquipmentSlot.HAND) return;
        // Drop Premium kartı
        if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ItemStack el = p.getInventory().getItemInMainHand();
            int gun = Premium.kartGunu(el);
            if (gun > 0) {
                e.setCancelled(true);
                el.setAmount(el.getAmount() - 1);
                Premium.gunEkle(p, gun);
                ZindanSistemi.msj(p, "§6§lDrop Premium §aetkinleştirildi! §7Kalan süre: §e" + Premium.kalan(p));
                p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
                return;
            }
        }
        // sandık
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null
                && e.getClickedBlock().getType() == Material.CHEST && zindanDunyasi(p.getWorld())) {
            Instance in = pl.oyuncuInstance.get(p.getUniqueId());
            if (in != null) {
                e.setCancelled(true);
                if (!in.sandikAc(p, e.getClickedBlock())) {
                    ZindanSistemi.msj(p, "§7Bu sandık henüz açılamaz.");
                }
            } else if (!p.hasPermission("zindan.admin")) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onNpc(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Entity en = e.getRightClicked();
        String tip = en.getPersistentDataContainer().get(ZindanSistemi.NPC_ANAHTAR, PersistentDataType.STRING);
        if (tip == null) return;
        e.setCancelled(true);
        pl.menuAc(e.getPlayer(), tip);
    }

    @EventHandler
    public void onNpcVurus(EntityDamageEvent e) {
        if (e.getEntity() instanceof Villager v
                && v.getPersistentDataContainer().has(ZindanSistemi.NPC_ANAHTAR, PersistentDataType.STRING)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onMenuTik(InventoryClickEvent e) {
        if (e.getInventory().getHolder() instanceof ZindanSistemi.Menu m) {
            e.setCancelled(true);
            if (e.getClickedInventory() != e.getInventory() || !(e.getWhoClicked() instanceof Player p)) return;
            Zorluk z = switch (e.getRawSlot()) {
                case 10 -> Zorluk.KOLAY;
                case 12 -> Zorluk.NORMAL;
                case 14 -> Zorluk.ZOR;
                case 16 -> Zorluk.OLUMCUL;
                default -> null;
            };
            if (z != null) {
                p.closeInventory();
                pl.girisDene(p, m.tip, z, false);
            }
        }
    }

    @EventHandler
    public void onMenuSurukle(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof ZindanSistemi.Menu) e.setCancelled(true);
    }

    // ================================================================== dünya koruması

    private boolean yetkiliYapi(Player p) {
        return p.hasPermission("zindan.admin") && p.getGameMode() == org.bukkit.GameMode.CREATIVE;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKir(BlockBreakEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld()) && !yetkiliYapi(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKoy(BlockPlaceEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld()) && !yetkiliYapi(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKova(org.bukkit.event.player.PlayerBucketEmptyEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld()) && !yetkiliYapi(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKovaDoldur(org.bukkit.event.player.PlayerBucketFillEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld()) && !yetkiliYapi(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPatlama(EntityExplodeEvent e) {
        if (zindanDunyasi(e.getEntity().getWorld())) e.blockList().clear();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlokPatlama(org.bukkit.event.block.BlockExplodeEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld())) e.blockList().clear();
    }

    /** Yaratıkların blok değiştirmesi / yıkması (enderman, wither, ravager, düşen blok...). */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onVarlikBlok(org.bukkit.event.entity.EntityChangeBlockEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKapiKir(org.bukkit.event.entity.EntityBreakDoorEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld())) e.setCancelled(true);
    }

    /** Lav/su akışı yapıyı bozmasın. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onAkis(org.bukkit.event.block.BlockFromToEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onYanma(org.bukkit.event.block.BlockBurnEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onYayilma(org.bukkit.event.block.BlockSpreadEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPistonIt(org.bukkit.event.block.BlockPistonExtendEvent e) {
        if (zindanDunyasi(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDogal(CreatureSpawnEvent e) {
        if (!zindanDunyasi(e.getLocation().getWorld())) return;
        switch (e.getSpawnReason()) {
            case NATURAL, CHUNK_GEN, PATROL, RAID, REINFORCEMENTS, VILLAGE_DEFENSE, VILLAGE_INVASION, TRAP, JOCKEY ->
                    e.setCancelled(true);
            default -> {
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onIsinlan(PlayerTeleportEvent e) {
        if (pl.oyuncuInstance.containsKey(e.getPlayer().getUniqueId())) {
            PlayerTeleportEvent.TeleportCause c = e.getCause();
            if (c == PlayerTeleportEvent.TeleportCause.ENDER_PEARL || c == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKomut(PlayerCommandPreprocessEvent e) {
        if (!pl.oyuncuInstance.containsKey(e.getPlayer().getUniqueId())) return;
        if (e.getPlayer().hasPermission("zindan.admin")) return;
        String m = e.getMessage().trim().toLowerCase();
        String ilk = m.startsWith("/") ? m.substring(1) : m;
        ilk = ilk.split("\\s+")[0];
        if (ilk.contains(":")) ilk = ilk.substring(ilk.indexOf(':') + 1);
        // beyaz liste: yalnızca burada yazılanlar kullanılabilir (admin hariç herkes)
        List<String> izinler = pl.getConfig().contains("izinli-komutlar")
                ? pl.getConfig().getStringList("izinli-komutlar") : List.of("zindan", "zd", "dungeon");
        for (String izin : izinler) {
            if (ilk.equals(izin.toLowerCase())) return;
        }
        e.setCancelled(true);
        ZindanSistemi.msj(e.getPlayer(), "§cZindanda komut kullanamazsın. Çıkmak için §f/zindan cik");
    }

    // ================================================================== giriş

    @EventHandler
    public void onGiris(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (!p.isOnline()) return;
            Instance in = pl.oyuncuInstance.get(id);
            if (in != null && in.durum == Instance.Durum.CALISIYOR && p.getWorld().equals(in.w)) {
                if (in.zamanBar != null) in.zamanBar.addPlayer(p);
                for (MobBilgi b : in.moblar.values()) if (b.bar != null) b.bar.addPlayer(p);
                in.girisKontrol(p);
                return;
            }
            if (in == null && pl.veri.bekleyenVar(id) && !zindanDunyasi(p.getWorld())) pl.teslim(p);
            if (zindanDunyasi(p.getWorld()) && in == null) {
                p.teleport(pl.veri.donus(id) != null ? pl.veri.donus(id) : Bukkit.getWorlds().get(0).getSpawnLocation());
                pl.veri.donusSil(id);
                ZindanSistemi.msj(p, "§7Zindan sona erdiği için dışarı alındın.");
                pl.teslim(p);
            }
        }, 20L);
    }
}
