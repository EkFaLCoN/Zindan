package net.mrwqlf.zindan;

/** Asmadeus kemik tablosu (gen/conv_asm.py tarafindan uretildi; elle degistirme). Birim: blok, merkez = govde pivotu. */
final class AsmadeusRig {
    private AsmadeusRig() {}

    static final String[] NAMES = {"body", "head", "arm_sword", "sword", "arm_left", "tail", "floating_armor", "cape"};
    static final int[] PARENT = {-1, 0, 0, 2, 0, 0, 0, 0};
    static final float[][] PIVOT = {
        {0.0000f, 0.0000f, 0.0000f},
        {0.0000f, 0.6250f, 0.0000f},
        {-0.5625f, 0.5000f, 0.0000f},
        {-0.5625f, -0.1250f, -0.6875f},
        {0.5625f, 0.5000f, 0.0000f},
        {0.0000f, -0.3750f, 0.0000f},
        {0.0000f, -0.5000f, 0.0000f},
        {0.0000f, 0.6875f, 0.1875f}
    };
}
