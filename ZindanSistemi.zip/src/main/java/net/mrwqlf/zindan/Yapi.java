package net.mrwqlf.zindan;

import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.block.data.type.Lantern;
import org.bukkit.block.data.type.PointedDripstone;
import org.bukkit.Bukkit;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Map;
import java.util.List;
import java.util.Random;

/** Zindan haritasını kutu (fill) işlemleri olarak üretir. Dünya boş (void) olduğundan yalnızca katı bloklar yerleştirilir. */
public final class Yapi {
    private Yapi() {
    }

    public record Kutu(int x1, int y1, int z1, int x2, int y2, int z2, BlockData veri) {
        public long hacim() {
            return (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
        }
    }

    private static BlockData d(Material m) {
        return Bukkit.createBlockData(m);
    }

    private static final Map<Material, BlockData> ONBELLEK = new EnumMap<>(Material.class);

    /** Değiştirilmeyecek blok verisi için önbellekli sürüm (binlerce kutu için hızlı). */
    private static BlockData dc(Material m) {
        return ONBELLEK.computeIfAbsent(m, mm -> Bukkit.createBlockData(mm));
    }

    private static void kutu(List<Kutu> o, int x1, int y1, int z1, int x2, int y2, int z2, Material m) {
        o.add(new Kutu(Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2),
                Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), dc(m)));
    }

    /** Oda listesini planlar. ox: instance başlangıç x'i. */
    public static List<Oda> planla(boolean parti, int ox, int oy, int oz) {
        int[][] spec;   // {tur(0 savas,1 parkur,2 boss), len, hw, h}
        if (parti) {
            spec = new int[][]{{0, 27, 12, 9}, {0, 33, 14, 10}, {1, 80, 12, 19}, {0, 33, 14, 10}, {0, 29, 13, 9}, {2, 45, 20, 20}};
        } else {
            spec = new int[][]{{0, 25, 12, 9}, {0, 25, 12, 9}, {0, 27, 12, 9}, {0, 29, 13, 9}, {0, 27, 12, 9}, {0, 31, 14, 10}, {2, 39, 18, 18}};
        }
        List<Oda> odalar = new ArrayList<>();
        int x = ox + 2;
        for (int i = 0; i < spec.length; i++) {
            Oda.Tur t = spec[i][0] == 0 ? Oda.Tur.SAVAS : spec[i][0] == 1 ? Oda.Tur.PARKUR : Oda.Tur.BOSS;
            odalar.add(new Oda(i, t, x, spec[i][1], spec[i][2], spec[i][3], oy, oz, i == spec.length - 1));
            x += spec[i][1] + 8;
        }
        return odalar;
    }

    /** Tüm yapının kapladığı x aralığı sonu. */
    public static int xBitis(List<Oda> o) {
        Oda s = o.get(o.size() - 1);
        return s.x0 + s.len + 3;
    }

    public static List<Kutu> uret(List<Oda> odalar, boolean parti) {
        List<Kutu> k = new ArrayList<>();
        for (Oda o : odalar) {
            oda(k, o, parti);
            if (!o.son) koridor(k, o);
        }
        return k;
    }

    // ------------------------------------------------------------------ tema (doğal mağara paleti)

    /** {ana kaya, yardımcı 1, yardımcı 2, zemine karışan özel blok}. Satır 6 = boss odası. */
    private static Material[] doga(Oda o) {
        Material[][] t = {
                {Material.STONE, Material.COBBLESTONE, Material.MOSSY_COBBLESTONE, Material.MOSS_BLOCK},
                {Material.DEEPSLATE, Material.COBBLED_DEEPSLATE, Material.TUFF, Material.GRAVEL},
                {Material.BLACKSTONE, Material.BASALT, Material.SMOOTH_BASALT, Material.GRAVEL},
                {Material.NETHERRACK, Material.BASALT, Material.BLACKSTONE, Material.SOUL_SAND},
                {Material.DEEPSLATE, Material.COBBLED_DEEPSLATE, Material.BLACKSTONE, Material.SCULK},
                {Material.BLACKSTONE, Material.BASALT, Material.GILDED_BLACKSTONE, Material.GRAVEL},
                {Material.OBSIDIAN, Material.BLACKSTONE, Material.CRYING_OBSIDIAN, Material.BLACKSTONE}};
        int row = o.tur == Oda.Tur.BOSS ? 6 : Math.min(o.index, 5);
        return t[row];
    }

    private static Material rastgeleKaya(Material[] p, Random r) {
        double x = r.nextDouble();
        return x < 0.72 ? p[0] : x < 0.9 ? p[1] : p[2];
    }

    private static BlockData sivri(boolean asagi, PointedDripstone.Thickness t) {
        BlockData b = d(Material.POINTED_DRIPSTONE);
        if (b instanceof PointedDripstone pd) {
            pd.setVerticalDirection(asagi ? BlockFace.DOWN : BlockFace.UP);
            pd.setThickness(t);
        }
        return b;
    }

    private static BlockData fener(boolean ruh) {
        BlockData b = d(ruh ? Material.SOUL_LANTERN : Material.LANTERN);
        if (b instanceof Lantern l) l.setHanging(true);
        return b;
    }

    // ------------------------------------------------------------------ oda

    private static void oda(List<Kutu> k, Oda o, boolean parti) {
        Material[] pal = doga(o);
        Material ana = pal[0], yard1 = pal[1], yard2 = pal[2], ozel = pal[3];
        Random r = new Random(7000L + o.index * 131L + (parti ? 17 : 0));
        boolean parkur = o.tur == Oda.Tur.PARKUR;
        boolean boss = o.tur == Oda.Tur.BOSS;
        int alt = parkur ? o.oy - 9 : o.oy - 1;           // kabuğun alt y'si
        int icAlt = parkur ? o.oy - 8 : o.oy;              // iç boşluğun alt y'si
        int zA = o.oz - o.hw, zB = o.oz + o.hw;
        int xa = o.x0, xb = o.x0 + o.len - 1;
        int yC = o.oy + o.h - 1;                           // iç boşluğun en üst y'si
        int gen = 2 * o.hw + 1;

        // kabuk + iç boşluk
        kutu(k, o.x0 - 1, alt, zA - 1, o.x0 + o.len, o.oy + o.h, zB + 1, ana);
        kutu(k, xa, icAlt, zA, xb, yC, zB, Material.AIR);

        int cxm = o.x0 + o.len / 2;
        // ---- zemin: şerit değil, düzensiz yamalar
        if (!parkur) {
            for (int x = xa; x <= xb; x++)
                for (int z = zA; z <= zB; z++) {
                    double q = r.nextDouble();
                    Material m = q < 0.66 ? ana : q < 0.86 ? yard1 : q < 0.94 ? yard2 : ozel;
                    kutu(k, x, o.oy - 1, z, x, o.oy - 1, z, m);
                }
        } else {
            kutu(k, xa, o.oy - 8, zA, xa + 4, o.oy - 1, zB, ana);
            kutu(k, xb - 4, o.oy - 8, zA, xb, o.oy - 1, zB, ana);
            kutu(k, xa + 5, o.oy - 8, zA, xb - 5, o.oy - 7, zB, Material.LAVA);
            parkurPlatformlari(k, o, yard1);
        }

        // ---- köşeleri yuvarla (kutu hissini kır)
        int cr = Math.min(5, o.hw / 3);
        for (int dx = 0; dx < cr; dx++)
            for (int dz = 0; dz < cr; dz++) {
                if (dx + dz > cr - 2) continue;
                for (int[] c : new int[][]{{xa + dx, zA + dz}, {xa + dx, zB - dz}, {xb - dx, zA + dz}, {xb - dx, zB - dz}})
                    kutu(k, c[0], icAlt, c[1], c[0], yC, c[1], rastgeleKaya(pal, r));
            }

        // ---- yan duvarlar: girinti/çıkıntılar (en çok 2 blok; yaratık doğma alanına taşmaz)
        int[] bumpA = new int[o.len], bumpB = new int[o.len];
        for (int i = 0; i < o.len; i++) {
            bumpA[i] = r.nextInt(4);
            bumpB[i] = r.nextInt(4);
        }
        for (int pass = 0; pass < 2; pass++)
            for (int i = 1; i < o.len - 1; i++) {
                bumpA[i] = (bumpA[i - 1] + bumpA[i] + bumpA[i + 1]) / 3;
                bumpB[i] = (bumpB[i - 1] + bumpB[i] + bumpB[i + 1]) / 3;
            }
        for (int i = 0; i < o.len; i++) {
            int x = xa + i;
            for (int side = 0; side < 2; side++) {
                int t = Math.min(2, side == 0 ? bumpA[i] : bumpB[i]);
                if (t <= 0 || r.nextInt(4) == 0) continue;
                int hv = 2 + r.nextInt(Math.max(1, o.h - 3));
                for (int kk = 0; kk < t; kk++) {
                    int z = side == 0 ? zA + kk : zB - kk;
                    kutu(k, x, icAlt, z, x, o.oy + hv - 1, z, rastgeleKaya(pal, r));
                }
            }
        }

        // ---- tavan: dalgalı (en çok 3 blok alçalır)
        int low = boss ? Math.min(3, o.h - 12) : Math.min(3, o.h - 7);
        low = Math.max(0, low);
        int[][] tav = new int[o.len][gen];
        int gx = o.len / 4 + 2, gz = gen / 4 + 2;
        int[][] kaba = new int[gx + 1][gz + 1];
        for (int[] row : kaba) for (int j = 0; j < row.length; j++) row[j] = r.nextInt(low + 1);
        for (int i = 0; i < o.len; i++)
            for (int j = 0; j < gen; j++) {
                double fx = i / 4.0, fz = j / 4.0;
                int x0i = (int) fx, z0i = (int) fz;
                double tx = fx - x0i, tz = fz - z0i;
                double v = (kaba[x0i][z0i] * (1 - tx) + kaba[x0i + 1][z0i] * tx) * (1 - tz)
                        + (kaba[x0i][z0i + 1] * (1 - tx) + kaba[x0i + 1][z0i + 1] * tx) * tz;
                tav[i][j] = (int) Math.round(v);
            }
        for (int i = 0; i < o.len; i++)
            for (int j = 0; j < gen; j++) {
                int c = tav[i][j];
                if (c <= 0) continue;
                int x = xa + i, z = zA + j;
                for (int y = yC - c + 1; y <= yC; y++) kutu(k, x, y, z, x, y, z, r.nextDouble() < 0.12 ? yard2 : ana);
            }

        // ---- korunan alanlar (kaya/dikit konmaz)
        boolean[][] yasak = new boolean[o.len][gen];
        for (int i = 0; i < o.len; i++)
            for (int j = 0; j < gen; j++) {
                int x = xa + i, z = zA + j;
                int dz = Math.abs(z - o.oz);
                boolean giris = i <= 6 && dz <= 5;
                boolean cikis = i >= o.len - 7 && dz <= 5;
                boolean sandik = x >= cxm - 1 && x <= cxm + 6 && dz <= 6;
                boolean halka = boss && Math.hypot(x - cxm, z - o.oz) <= 8.5;
                yasak[i][j] = giris || cikis || sandik || halka;
            }

        if (!parkur) {
            // ---- kaya yığınları
            int adet = o.len * gen / 80;
            for (int n = 0; n < adet; n++) {
                int bi = 1 + r.nextInt(o.len - 2), bj = 1 + r.nextInt(gen - 2);
                int rad = 1 + r.nextInt(2);
                for (int dx = -rad; dx <= rad; dx++)
                    for (int dz = -rad; dz <= rad; dz++) {
                        int i = bi + dx, j = bj + dz;
                        if (i < 0 || j < 0 || i >= o.len || j >= gen || yasak[i][j]) continue;
                        double dist = Math.hypot(dx, dz);
                        if (dist > rad + 0.3) continue;
                        int yuk = Math.max(1, (int) Math.round(rad + 0.6 - dist * 0.8));
                        kutu(k, xa + i, o.oy, zA + j, xa + i, o.oy + yuk - 1, zA + j, rastgeleKaya(pal, r));
                    }
            }
            // ---- dikitler
            for (int n = 0; n < o.len * gen / 160; n++) {
                int i = r.nextInt(o.len), j = r.nextInt(gen);
                if (yasak[i][j]) continue;
                int x = xa + i, z = zA + j;
                if (r.nextBoolean()) {
                    kutu(k, x, o.oy - 1, z, x, o.oy - 1, z, Material.DRIPSTONE_BLOCK);
                    k.add(new Kutu(x, o.oy, z, x, o.oy, z, sivri(false, PointedDripstone.Thickness.FRUSTUM)));
                    k.add(new Kutu(x, o.oy + 1, z, x, o.oy + 1, z, sivri(false, PointedDripstone.Thickness.TIP)));
                } else {
                    k.add(new Kutu(x, o.oy, z, x, o.oy, z, sivri(false, PointedDripstone.Thickness.TIP)));
                }
            }
        }
        // ---- sarkıtlar
        for (int n = 0; n < o.len * gen / 70; n++) {
            int i = r.nextInt(o.len), j = r.nextInt(gen);
            int x = xa + i, z = zA + j;
            int c = tav[i][j];
            int y = yC - c;                        // tavanın altındaki ilk hava bloğu
            if (parkur && r.nextBoolean()) continue;
            kutu(k, x, y + 1, z, x, y + 1, z, Material.DRIPSTONE_BLOCK);
            if (r.nextBoolean()) {
                k.add(new Kutu(x, y, z, x, y, z, sivri(true, PointedDripstone.Thickness.FRUSTUM)));
                k.add(new Kutu(x, y - 1, z, x, y - 1, z, sivri(true, PointedDripstone.Thickness.TIP)));
            } else {
                k.add(new Kutu(x, y, z, x, y, z, sivri(true, PointedDripstone.Thickness.TIP)));
            }
        }

        // ---- ışık: sarkan fenerler + tavana gömülü shroomlight (ızgara yok, dağınık)
        boolean ruh = o.index >= 2 || boss;
        for (int x = xa + 3; x < xb - 1; x += 6) {
            for (int z = zA + 3; z <= zB - 3; z += 6) {
                int xx = x + r.nextInt(3) - 1, zz = z + r.nextInt(3) - 1;
                int i = Math.max(0, Math.min(o.len - 1, xx - xa)), j = Math.max(0, Math.min(gen - 1, zz - zA));
                int c = tav[i][j];
                if (r.nextDouble() < 0.6) {
                    k.add(new Kutu(xx, yC - c, zz, xx, yC - c, zz, fener(ruh)));
                } else {
                    kutu(k, xx, yC - c + 1, zz, xx, yC - c + 1, zz, Material.SHROOMLIGHT);
                }
            }
        }

        // boss odasında ortada ritüel halkası
        if (boss) {
            int cx = cxm, cz = o.oz;
            for (int dx = -6; dx <= 6; dx++) {
                for (int dz = -6; dz <= 6; dz++) {
                    int r2 = dx * dx + dz * dz;
                    if (r2 >= 25 && r2 <= 36) {
                        kutu(k, cx + dx, o.oy - 1, cz + dz, cx + dx, o.oy - 1, cz + dz, Material.CRYING_OBSIDIAN);
                    }
                }
            }
        }

        // giriş açıklığı (ilk oda hariç)
        if (o.index > 0) {
            kutu(k, o.x0 - 1, o.oy, o.oz - 2, o.x0 - 1, o.oy + 3, o.oz + 2, Material.AIR);
        }
        // çıkış kapısı (demir parmaklık)
        if (!o.son) {
            int[] kp = o.kapi();
            // fizik kapalı yerleştirildiğinden parmaklıklar birbirine bağlanmaz; bağlantıyı elle veriyoruz
            BlockData bars = d(Material.IRON_BARS);
            if (bars instanceof MultipleFacing mf) {
                mf.setFace(BlockFace.NORTH, true);
                mf.setFace(BlockFace.SOUTH, true);
                bars = mf;
            }
            k.add(new Kutu(kp[0], kp[1], kp[2], kp[0], kp[3], kp[4], bars));
            // arkasına görünmez bariyer: oyuncu/yaratık aralardan geçemesin
            int[] br = o.kapiBariyer();
            kutu(k, br[0], br[1], br[2], br[0], br[3], br[4], Material.BARRIER);
        }
    }

    private static void koridor(List<Kutu> k, Oda o) {
        Material[] pal = doga(o);
        Random r = new Random(9100L + o.index);
        int xa = o.x0 + o.len + 1, xb = o.x0 + o.len + 6;
        kutu(k, xa, o.oy - 1, o.oz - 3, xb, o.oy + 5, o.oz + 3, pal[0]);
        kutu(k, xa, o.oy, o.oz - 2, xb, o.oy + 4, o.oz + 2, Material.AIR);
        for (int x = xa; x <= xb; x++)
            for (int z = o.oz - 2; z <= o.oz + 2; z++)
                kutu(k, x, o.oy - 1, z, x, o.oy - 1, z, r.nextDouble() < 0.7 ? pal[0] : pal[1]);
        kutu(k, xa + 2, o.oy + 4, o.oz + 1, xa + 2, o.oy + 4, o.oz + 1, Material.SHROOMLIGHT);
        kutu(k, xb - 1, o.oy + 4, o.oz - 1, xb - 1, o.oy + 4, o.oz - 1, Material.SHROOMLIGHT);
    }

    // ------------------------------------------------------------------ parkur

    /**
     * Zor parkur: çoğu 1x1 platform, 2-3 blok boşluklu sprint atlayışları, yanal kaymalar, iniş/çıkışlar,
     * kayan buz ve basınca çöken (çatlak derin kayrak karo) platformlar. Çöken platformun işareti CRACKED_DEEPSLATE_TILES'tır.
     */
    private static void parkurPlatformlari(List<Kutu> k, Oda o, Material yard) {
        Random r = new Random(4242L + o.index);
        int x = o.x0 + 4;               // başlangıç platformunun son x'i
        int z = o.oz;
        int y = o.oy - 1;
        int bitis = o.x0 + o.len - 6;   // bitiş platformu bitis+1'de başlar
        int[] inisCikis = {-2, -1, -1, 0, 0, 1};
        int adim = 0;
        while (true) {
            int gap = adim < 2 ? 3 : 3 + (r.nextInt(3) == 0 ? 1 : 0);        // 2 veya 3 boş blok
            int dz = r.nextInt(7) - 3;
            while (gap * gap + dz * dz > 17) dz = Integer.signum(dz) * (Math.abs(dz) - 1);
            int dy = adim > 1 ? inisCikis[r.nextInt(inisCikis.length)] : 0;
            if (dy == 1 && gap > 3) dy = 0;
            int tip = adim < 2 ? 0 : r.nextInt(7);
            int nx = x + gap;
            int nz = Math.max(o.oz - o.hw + 3, Math.min(o.oz + o.hw - 3, z + dz));
            int ny = Math.max(o.oy - 4, Math.min(o.oy + 2, y + dy));
            int geriDonus = 3 * Math.max(0, (o.oy - 1) - ny);                 // sona doğru seviyeye dönmek için yer ayır
            if (nx >= bitis - 1 - geriDonus) break;
            Material m = switch (tip) {
                case 0 -> Material.ANDESITE;
                case 1 -> Material.BLACKSTONE;
                case 2 -> Material.PACKED_ICE;
                case 3, 4 -> Material.CRACKED_DEEPSLATE_TILES;                // basınca çöker
                case 5 -> Material.COBBLED_DEEPSLATE;
                default -> yard;
            };
            kutu(k, nx, ny, nz, nx, ny, nz, m);
            x = nx;
            z = nz;
            y = ny;
            adim++;
        }
        // seviyeyi bitiş platformuna getir (her basamak +1 yukarı)
        while (y < o.oy - 1) {
            x += 3;
            y += 1;
            kutu(k, x, y, z, x, y, z, Material.COBBLED_DEEPSLATE);
        }
        // bitiş platformuna son sıçrama en çok 3 boş blok olsun
        while (bitis + 1 - x > 4) {
            x += 3;
            kutu(k, x, y, z, x, y, z, Material.COBBLED_DEEPSLATE);
        }
    }

    // ------------------------------------------------------------------ sandık

    public static Kutu sandik(Oda o, int[] p) {
        BlockData bd = d(Material.CHEST);
        if (bd instanceof Directional dir) {
            dir.setFacing(BlockFace.valueOf(o.sandikYonu()));
        }
        return new Kutu(p[0], p[1], p[2], p[0], p[1], p[2], bd);
    }

    public static Kutu hava(Kutu x) {
        return new Kutu(x.x1(), x.y1(), x.z1(), x.x2(), x.y2(), x.z2(), d(Material.AIR));
    }
}
