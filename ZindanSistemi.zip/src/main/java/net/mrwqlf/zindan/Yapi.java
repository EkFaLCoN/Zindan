package net.mrwqlf.zindan;

import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.Bukkit;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Zindan haritasını kutu (fill) işlemleri olarak üretir. Dünya boş (void) olduğundan yalnızca katı bloklar yerleştirilir. */
public final class Yapi {
    private Yapi() {
    }

    public record Kutu(int x1, int y1, int z1, int x2, int y2, int z2, BlockData veri) {
        public long hacim() {
            return (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
        }
    }

    private static BlockData d(Material m) {
        return Bukkit.createBlockData(m);
    }

    private static void kutu(List<Kutu> o, int x1, int y1, int z1, int x2, int y2, int z2, Material m) {
        o.add(new Kutu(Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2),
                Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), d(m)));
    }

    /** Oda listesini planlar. ox: instance başlangıç x'i. */
    public static List<Oda> planla(boolean parti, int ox, int oy, int oz) {
        int[][] spec;   // {tur(0 savas,1 parkur,2 boss), len, hw, h}
        if (parti) {
            spec = new int[][]{{0, 27, 12, 9}, {0, 33, 14, 10}, {1, 56, 12, 16}, {0, 33, 14, 10}, {0, 29, 13, 9}, {2, 45, 20, 20}};
        } else {
            spec = new int[][]{{0, 25, 12, 9}, {0, 25, 12, 9}, {0, 27, 12, 9}, {0, 29, 13, 9}, {0, 27, 12, 9}, {0, 31, 14, 10}, {2, 39, 18, 18}};
        }
        List<Oda> odalar = new ArrayList<>();
        int x = ox + 2;
        for (int i = 0; i < spec.length; i++) {
            Oda.Tur t = spec[i][0] == 0 ? Oda.Tur.SAVAS : spec[i][0] == 1 ? Oda.Tur.PARKUR : Oda.Tur.BOSS;
            odalar.add(new Oda(i, t, x, spec[i][1], spec[i][2], spec[i][3], oy, oz, i == spec.length - 1));
            x += spec[i][1] + 8;
        }
        return odalar;
    }

    /** Tüm yapının kapladığı x aralığı sonu. */
    public static int xBitis(List<Oda> o) {
        Oda s = o.get(o.size() - 1);
        return s.x0 + s.len + 3;
    }

    public static List<Kutu> uret(List<Oda> odalar, boolean parti) {
        List<Kutu> k = new ArrayList<>();
        for (Oda o : odalar) {
            oda(k, o, parti);
            if (!o.son) koridor(k, o);
        }
        return k;
    }

    // ------------------------------------------------------------------ tema

    private static Material[] duvar(int i, boolean parti) {
        Material[][] t = parti
                ? new Material[][]{
                {Material.MOSSY_STONE_BRICKS, Material.STONE_BRICKS},
                {Material.DEEPSLATE_BRICKS, Material.CRACKED_DEEPSLATE_BRICKS},
                {Material.POLISHED_BLACKSTONE_BRICKS, Material.BLACKSTONE},
                {Material.NETHER_BRICKS, Material.RED_NETHER_BRICKS},
                {Material.DEEPSLATE_TILES, Material.POLISHED_DEEPSLATE},
                {Material.OBSIDIAN, Material.CRYING_OBSIDIAN}}
                : new Material[][]{
                {Material.STONE_BRICKS, Material.MOSSY_STONE_BRICKS},
                {Material.DEEPSLATE_BRICKS, Material.CRACKED_DEEPSLATE_BRICKS},
                {Material.BLACKSTONE, Material.POLISHED_BLACKSTONE_BRICKS},
                {Material.NETHER_BRICKS, Material.RED_NETHER_BRICKS},
                {Material.DEEPSLATE_TILES, Material.POLISHED_DEEPSLATE},
                {Material.POLISHED_BLACKSTONE_BRICKS, Material.GILDED_BLACKSTONE},
                {Material.OBSIDIAN, Material.CRYING_OBSIDIAN}};
        return t[Math.min(i, t.length - 1)];
    }

    // ------------------------------------------------------------------ oda

    private static void oda(List<Kutu> k, Oda o, boolean parti) {
        Material[] tema = duvar(o.index, parti);
        Material duvar = tema[0], zemin2 = tema[1];
        boolean parkur = o.tur == Oda.Tur.PARKUR;
        int alt = parkur ? o.oy - 9 : o.oy - 1;           // kabuğun alt y'si
        int icAlt = parkur ? o.oy - 8 : o.oy;              // iç boşluğun alt y'si
        int zA = o.oz - o.hw, zB = o.oz + o.hw;

        // kabuk + iç boşluk
        kutu(k, o.x0 - 1, alt, zA - 1, o.x0 + o.len, o.oy + o.h, zB + 1, duvar);
        kutu(k, o.x0, icAlt, zA, o.x0 + o.len - 1, o.oy + o.h - 1, zB, Material.AIR);

        if (!parkur) {
            // zemin deseni: x'e göre şeritler
            for (int x = o.x0; x < o.x0 + o.len; x++) {
                kutu(k, x, o.oy - 1, zA, x, o.oy - 1, zB, (x % 2 == 0) ? duvar : zemin2);
            }
        } else {
            // başlangıç ve bitiş platformu + lav çukuru
            kutu(k, o.x0, o.oy - 8, zA, o.x0 + 4, o.oy - 1, zB, duvar);
            kutu(k, o.x0 + o.len - 5, o.oy - 8, zA, o.x0 + o.len - 1, o.oy - 1, zB, duvar);
            kutu(k, o.x0 + 5, o.oy - 8, zA, o.x0 + o.len - 6, o.oy - 7, zB, Material.LAVA);
            parkurPlatformlari(k, o, zemin2);
        }

        // ışıklar: tavana shroomlight ızgarası
        for (int x = o.x0 + 3; x < o.x0 + o.len - 1; x += 6) {
            for (int z = zA + 3; z <= zB - 2; z += 6) {
                kutu(k, x, o.oy + o.h, z, x, o.oy + o.h, z, Material.SHROOMLIGHT);
            }
        }
        // yan duvar sütunları (süs)
        for (int x = o.x0 + 2; x < o.x0 + o.len - 1; x += 6) {
            kutu(k, x, o.oy, zA, x, o.oy + o.h - 1, zA, Material.CHISELED_POLISHED_BLACKSTONE);
            kutu(k, x, o.oy, zB, x, o.oy + o.h - 1, zB, Material.CHISELED_POLISHED_BLACKSTONE);
        }
        // boss odasında ortada ritüel halkası
        if (o.tur == Oda.Tur.BOSS) {
            int cx = o.x0 + o.len / 2, cz = o.oz;
            for (int dx = -6; dx <= 6; dx++) {
                for (int dz = -6; dz <= 6; dz++) {
                    int r2 = dx * dx + dz * dz;
                    if (r2 >= 25 && r2 <= 36) {
                        kutu(k, cx + dx, o.oy - 1, cz + dz, cx + dx, o.oy - 1, cz + dz, Material.CRYING_OBSIDIAN);
                    }
                }
            }
        }

        // giriş açıklığı (ilk oda hariç)
        if (o.index > 0) {
            kutu(k, o.x0 - 1, o.oy, o.oz - 2, o.x0 - 1, o.oy + 3, o.oz + 2, Material.AIR);
        }
        // çıkış kapısı (demir parmaklık)
        if (!o.son) {
            int[] kp = o.kapi();
            // fizik kapalı yerleştirildiğinden parmaklıklar birbirine bağlanmaz; bağlantıyı elle veriyoruz
            BlockData bars = d(Material.IRON_BARS);
            if (bars instanceof MultipleFacing mf) {
                mf.setFace(BlockFace.NORTH, true);
                mf.setFace(BlockFace.SOUTH, true);
                bars = mf;
            }
            k.add(new Kutu(kp[0], kp[1], kp[2], kp[0], kp[3], kp[4], bars));
            // arkasına görünmez bariyer: oyuncu/yaratık aralardan geçemesin
            int[] br = o.kapiBariyer();
            kutu(k, br[0], br[1], br[2], br[0], br[3], br[4], Material.BARRIER);
        }
    }

    private static void koridor(List<Kutu> k, Oda o) {
        int xa = o.x0 + o.len + 1, xb = o.x0 + o.len + 6;
        kutu(k, xa, o.oy - 1, o.oz - 3, xb, o.oy + 5, o.oz + 3, Material.POLISHED_BLACKSTONE_BRICKS);
        kutu(k, xa, o.oy, o.oz - 2, xb, o.oy + 4, o.oz + 2, Material.AIR);
        kutu(k, xa + 2, o.oy + 5, o.oz, xa + 2, o.oy + 5, o.oz, Material.SEA_LANTERN);
        kutu(k, xb - 1, o.oy + 5, o.oz, xb - 1, o.oy + 5, o.oz, Material.SEA_LANTERN);
    }

    // ------------------------------------------------------------------ parkur

    private static void parkurPlatformlari(List<Kutu> k, Oda o, Material zemin2) {
        Random r = new Random(4242L + o.index);
        int x = o.x0 + 5;               // ilk platform ayrılma noktası (başlangıç platformunun hemen ardı)
        int z = o.oz;
        int y = o.oy - 1;
        int bitis = o.x0 + o.len - 6;
        int adim = 0;
        while (true) {
            int gap = 2 + (adim > 3 && r.nextInt(3) == 0 ? 1 : 0);   // 2 veya 3
            int dz = r.nextInt(5) - 2;
            while (gap * gap + dz * dz > 10) dz = Integer.signum(dz) * (Math.abs(dz) - 1);
            int dy = adim > 1 ? r.nextInt(3) - 1 : 0;
            if (dy == 1 && gap > 2) gap = 2;
            int tip = r.nextInt(5);
            int boyut = (tip <= 1) ? 2 : 1;
            int nx = x + gap;                 // platformun ilk x'i
            if (nx + boyut - 1 >= bitis - 1) break;
            int nz = Math.max(o.oz - o.hw + 3, Math.min(o.oz + o.hw - 3, z + dz));
            int ny = Math.max(o.oy - 2, Math.min(o.oy + 1, y + dy));
            Material m = switch (tip) {
                case 0 -> Material.STONE_BRICKS;
                case 1 -> Material.PACKED_ICE;
                case 2 -> Material.DEEPSLATE_BRICKS;
                case 3 -> zemin2;
                default -> Material.POLISHED_BLACKSTONE;
            };
            kutu(k, nx, ny, nz, nx + boyut - 1, ny, nz + boyut - 1, m);
            x = nx + boyut - 1;
            z = nz;
            y = ny;
            adim++;
        }
        // son platformdan bitişe köprü: bitiş platformu x=bitis+1'de başlar; son sıçrama için ek taş
        int son = bitis - x;
        if (son > 3) {
            kutu(k, x + 3, y, z, x + 3, y, z, Material.DEEPSLATE_BRICKS);
        }
    }

    // ------------------------------------------------------------------ sandık

    public static Kutu sandik(Oda o, int[] p) {
        BlockData bd = d(Material.CHEST);
        if (bd instanceof Directional dir) {
            dir.setFacing(BlockFace.valueOf(o.sandikYonu()));
        }
        return new Kutu(p[0], p[1], p[2], p[0], p[1], p[2], bd);
    }

    public static Kutu hava(Kutu x) {
        return new Kutu(x.x1(), x.y1(), x.z1(), x.x2(), x.y2(), x.z2(), d(Material.AIR));
    }
}
