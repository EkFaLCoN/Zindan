package net.mrwqlf.zindan;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.Giant;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.lang.reflect.Method;

/**
 * Zindanın Mini Overlord'u (5000 can). Görünüm CursedValleyMobsAndMob'un OverlordModel'i yansımayla kullanılır;
 * eklenti yoksa Giant görünür kalır. Hasarı Warden'dan 2 kalp (4 can) azdır.
 */
public final class MiniOverlord {
    private final Instance in;
    private final Giant giant;
    private final MobBilgi bilgi;
    private Object model;
    private Method mTick, mRemove, mAttack;
    private int atkSayac = 0, ziplaSayac = 120;
    private BukkitRunnable gorev;

    private MiniOverlord(Instance in, Giant giant, MobBilgi bilgi) {
        this.in = in;
        this.giant = giant;
        this.bilgi = bilgi;
    }

    public static MiniOverlord yap(Instance in, Location l, int oda) {
        float olcek = (float) in.pl.getConfig().getDouble("mini-overlord.olcek", 2.4);
        Giant g = in.mobYap(Giant.class, l, "mini_overlord", "Mini Overlord", 5000, true, false, true, oda, e -> {
            var sc = e.getAttribute(Attribute.SCALE);
            if (sc != null) sc.setBaseValue(olcek / 4.0);
        });
        MobBilgi b = in.moblar.get(g.getUniqueId());
        MiniOverlord m = new MiniOverlord(in, g, b);
        m.modelKur(olcek);
        in.bossBar(g, "§d§lMini Overlord", BarColor.PURPLE);
        m.baslat();
        l.getWorld().playSound(l, Sound.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 2f, 1.5f);
        return m;
    }

    private void modelKur(float olcek) {
        try {
            Plugin cv = Bukkit.getPluginManager().getPlugin("CursedValleyMobsAndMob");
            if (cv == null || !cv.isEnabled()) return;
            Class<?> c = cv.getClass().getClassLoader().loadClass("net.cursedvalley.mobs.OverlordModel");
            model = c.getConstructor(JavaPlugin.class, float.class).newInstance(cv, olcek);
            c.getMethod("spawn", Giant.class).invoke(model, giant);
            mTick = c.getMethod("tick", Giant.class);
            mRemove = c.getMethod("remove");
            mAttack = c.getMethod("playAttack");
            giant.setInvisible(true);
        } catch (ReflectiveOperationException | RuntimeException e) {
            model = null;
            giant.setInvisible(false);
        }
    }

    private void baslat() {
        gorev = new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!giant.isValid() || in.durum != Instance.Durum.CALISIYOR) {
                    kaldir();
                    return;
                }
                t++;
                if (model != null && mTick != null) {
                    try {
                        mTick.invoke(model, giant);
                    } catch (ReflectiveOperationException ignored) {
                        model = null;
                    }
                }
                if (t % 5 == 0) yapayZeka();
            }
        };
        gorev.runTaskTimer(in.pl, 1L, 1L);
    }

    private void yapayZeka() {
        Player p = in.enYakin(giant.getLocation(), 90);
        if (p == null) return;
        giant.setTarget(p);
        double mesafe = p.getLocation().distance(giant.getLocation());
        double olcek = in.pl.getConfig().getDouble("mini-overlord.olcek", 2.4);
        double menzil = 1.4 * olcek + 1.5;
        if (mesafe > menzil - 1) giant.getPathfinder().moveTo(p.getLocation(), 1.1);
        atkSayac -= 5;
        ziplaSayac -= 5;
        // Warden hasarından 2 kalp (4 can) az
        double taban = in.pl.getConfig().getDouble("hasar.warden", 30.0) - 4.0;
        if (atkSayac <= 0 && mesafe <= menzil) {
            atkSayac = 28;
            vur(p, taban * in.z.hasar, 0.9);
            if (mAttack != null && model != null) {
                try {
                    mAttack.invoke(model);
                } catch (ReflectiveOperationException ignored) {
                    // animasyon yoksa geç
                }
            }
            giant.getWorld().playSound(giant.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.HOSTILE, 1.5f, 0.6f);
        }
        // yere vuruş: yakındakilere alan hasarı
        if (ziplaSayac <= 0 && mesafe < menzil + 10) {
            ziplaSayac = 200;
            Location c = giant.getLocation();
            giant.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 2f, 0.5f);
            giant.getWorld().spawnParticle(Particle.EXPLOSION, c, 6, 3, 0.2, 3, 0);
            for (Player q : in.aktifOyuncular()) {
                if (q.getLocation().distanceSquared(c) <= 8 * 8) {
                    q.damage(taban * 0.6 * in.z.hasar, giant);
                    q.setVelocity(q.getVelocity().add(new Vector(0, 0.8, 0)));
                }
            }
        }
    }

    private void vur(Player p, double hasar, double itme) {
        p.damage(hasar, giant);
        Vector kb = p.getLocation().toVector().subtract(giant.getLocation().toVector()).setY(0);
        if (kb.lengthSquared() > 0) p.setVelocity(p.getVelocity().add(kb.normalize().multiply(itme).setY(0.35)));
    }

    public void kaldir() {
        if (gorev != null) {
            try {
                gorev.cancel();
            } catch (IllegalStateException ignored) {
                // zaten iptal
            }
            gorev = null;
        }
        if (model != null && mRemove != null) {
            try {
                mRemove.invoke(model);
            } catch (ReflectiveOperationException ignored) {
                // geç
            }
            model = null;
        }
    }
}
