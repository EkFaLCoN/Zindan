package net.mrwqlf.zindan;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.WitherSkeleton;
import org.bukkit.entity.Zombie;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * ASMADEUS — 25000 canlı zindan bossu. 8 kemikli ItemDisplay iskeleti (AsmadeusRig) + görünmez Zombie hitbox'ı.
 * 6 yetenek: Ölüm Kılıcı, Ruh Mermileri, Gölge Adımı, Lanet Çemberi, Ruh Çağrısı, Ruh Çekimi.
 */
public final class AsmadeusBoss {
    private enum Anim { IDLE, SLASH, CAST, SLAM }

    private enum Yetenek { KILIC, MERMI, GOLGE, CEMBER, CAGRI, CEKIM }

    private static final class Mermi {
        Location konum;
        Vector hiz;
        int omur = 70;
        Player hedef;
    }

    private final Instance in;
    private final Oda oda;
    private final Zombie ent;
    private final MobBilgi bilgi;
    private final ItemDisplay[] parcalar = new ItemDisplay[AsmadeusRig.NAMES.length];
    private final Random rnd = new Random();
    private final double olcek;
    private final double hasarCarpan;
    private BukkitRunnable gorev;

    private int t = 0;
    /** Kılıç bileğinin eğimi: dinlenirken namlu öne eğik (hazır duruş), saldırılarda eski pozisyona döner. */
    private float kEgim = -0.85f;
    private Anim anim = Anim.IDLE;
    private int animT = 0, animUzun = 1;
    private Yetenek aktif = null;
    private int yetT = 0;
    private int bekleme = 80;
    private Yetenek son = null;
    private boolean faz2 = false;
    private boolean olu = false;
    private int oluT = 0;
    private double yaw = 0;          // gövde yönü (radyan, model için)
    private Vector bakis = new Vector(0, 0, 1);
    private double hareketHizi = 0;
    private final List<Mermi> mermiler = new ArrayList<>();
    private final List<Location> cemberler = new ArrayList<>();
    private Vector dalgaYon;
    private Location golgeHedef;

    public AsmadeusBoss(Instance in, Oda oda) {
        this.in = in;
        this.oda = oda;
        this.olcek = in.pl.getConfig().getDouble("asmadeus.olcek", 1.8);
        this.hasarCarpan = in.z.hasar;
        Location merkez = oda.merkez(in.w).add(0, 0, 0);
        double yuk = in.pl.getConfig().getDouble("asmadeus.havada-yukseklik", 1.6);
        Location baslangic = merkez.clone().add(oda.len / 4.0, yuk, 0);
        this.ent = in.mobYap(Zombie.class, baslangic, "asmadeus", "ASMADEUS", 25000, true, false, true, oda.index, z -> {
            z.setAI(false);
            z.setGravity(false);
            z.setSilent(true);
            z.setInvisible(true);
            z.setBaby(false);
            z.setShouldBurnInDay(false);
            z.setCanPickupItems(false);
            var sc = z.getAttribute(Attribute.SCALE);
            if (sc != null) sc.setBaseValue(olcek * 1.45);
            z.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, PotionEffect.INFINITE_DURATION, 0, false, false));
        });
        this.bilgi = in.moblar.get(ent.getUniqueId());
        in.bossBar(ent, "§5§lASMADEUS §7- Hayalet Şövalye", BarColor.PURPLE);
        kemikleriYarat();
        in.herkeseBaslik("§5§lASMADEUS", "§7Ruhların efendisi uyandı...");
        for (Player p : in.aktifOyuncular()) p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 2f, 0.5f);
        gorev = new BukkitRunnable() {
            @Override
            public void run() {
                tick();
            }
        };
        gorev.runTaskTimer(in.pl, 1L, 1L);
    }

    // ================================================================== görünüm

    private void kemikleriYarat() {
        String varyant = in.pl.getConfig().getString("asmadeus.model-varyanti", "");
        if (varyant == null || varyant.equalsIgnoreCase("a")) varyant = "";
        else if (varyant.equalsIgnoreCase("b")) varyant = "_b";
        Location l = govdeKonumu();
        Transformation[] tr = poz();
        for (int i = 0; i < parcalar.length; i++) {
            ItemStack it = new ItemStack(Material.PAPER);
            ItemMeta m = it.getItemMeta();
            m.setItemModel(new NamespacedKey("zindan", "asmadeus" + varyant + "/" + AsmadeusRig.NAMES[i]));
            it.setItemMeta(m);
            final int bi = i;
            parcalar[i] = in.w.spawn(l, ItemDisplay.class, d -> {
                d.setItemStack(it);
                d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                d.setBillboard(Display.Billboard.FIXED);
                d.setViewRange(5.0f);
                d.setDisplayWidth(80f);
                d.setDisplayHeight(80f);
                d.setBrightness(new Display.Brightness(15, 15));
                d.setPersistent(false);
                d.setInterpolationDuration(0);
                d.setTeleportDuration(0);
                d.setTransformation(tr[bi]);
                d.addScoreboardTag("zd_parca");
            });
        }
    }

    /** Modelin merkezinin (gövde pivotu) dünya konumu. */
    private Location govdeKonumu() {
        Location e = ent.getLocation();
        return e.clone().add(0, 1.5 * olcek, 0);
    }

    private static float yumusat(float a, float b, float k) {
        return a + (b - a) * k;
    }

    private Transformation[] poz() {
        int n = parcalar.length;
        Quaternionf[] lq = new Quaternionf[n];
        for (int i = 0; i < n; i++) lq[i] = new Quaternionf();
        float tt = t;

        // ----- animasyon parametreleri
        float kilic = 0.25f + 0.05f * (float) Math.sin(tt * 0.1);
        float solKol = 0.12f * (float) Math.sin(tt * 0.09 + 1);
        float pelerin = -(0.18f + 0.10f * (float) Math.sin(tt * 0.12));
        float gövdeEgim = (float) (-hareketHizi * 0.9);
        float basYaw = 0, basEgim = 0;

        float a = animT;
        switch (anim) {
            case SLASH -> {
                if (a < 10) kilic = yumusat(0.25f, 1.6f, a / 10f);
                else if (a < 14) kilic = yumusat(1.6f, -0.9f, (a - 10) / 4f);
                else if (a < 24) kilic = -0.9f;
                else kilic = yumusat(-0.9f, 0.25f, Math.min(1f, (a - 24) / 6f));
                gövdeEgim += (a >= 10 && a < 24) ? -0.25f : 0.1f;
                pelerin -= 0.2f;
            }
            case CAST -> {
                float k = Math.min(1f, a / 8f);
                kilic = yumusat(kilic, 1.0f, k);
                solKol = yumusat(solKol, 2.5f, k);
                pelerin -= 0.45f * k;
                gövdeEgim += 0.18f * k;
                basEgim = -0.2f * k;
            }
            case SLAM -> {
                if (a < 20) {
                    float k = Math.min(1f, a / 14f);
                    kilic = yumusat(0.25f, 2.0f, k);
                    solKol = yumusat(0.1f, 2.6f, k);
                    gövdeEgim += 0.2f * k;
                } else {
                    float k = Math.min(1f, (a - 20) / 5f);
                    kilic = yumusat(2.0f, -1.0f, k);
                    solKol = yumusat(2.6f, 0.2f, k);
                    gövdeEgim -= 0.35f * k;
                }
            }
            default -> {
            }
        }
        if (olu) {
            float k = Math.min(1f, oluT / 30f);
            kilic = yumusat(kilic, -0.5f, k);
            solKol = yumusat(solKol, 0.8f, k);
            pelerin = -0.9f * k;
        }

        float hedefEgim = (anim == Anim.IDLE && !olu) ? -0.85f + 0.04f * (float) Math.sin(tt * 0.08) : 0f;
        kEgim += (hedefEgim - kEgim) * 0.2f;

        // bakış: gövdeye göre başı hedefe çevir (yaw: dünya -> yerel)
        Player hedef = aktifHedef();
        if (hedef != null) {
            Vector v = hedef.getEyeLocation().toVector().subtract(govdeKonumu().toVector());
            double dunyaYaw = Math.atan2(-v.getX(), -v.getZ());
            double fark = dunyaYaw - yaw;
            while (fark > Math.PI) fark -= 2 * Math.PI;
            while (fark < -Math.PI) fark += 2 * Math.PI;
            basYaw = (float) Math.max(-0.9, Math.min(0.9, fark));
        }

        // kemik başına yerel dönüşler (X ekseni etrafında + ek)
        lq[1] = new Quaternionf().rotateY(basYaw).rotateX(basEgim);                       // head
        lq[2] = new Quaternionf().rotateX(kilic);                                          // arm_sword (kılıç çocuğu ile birlikte)
        lq[3] = new Quaternionf().rotateX(kEgim);                                          // sword: elde tutulan kılıç (yumruk pivotu)
        lq[4] = new Quaternionf().rotateX(solKol);                                         // arm_left
        lq[5] = new Quaternionf().rotateY(0.25f * (float) Math.sin(tt * 0.1)).rotateX(-0.12f * (float) Math.sin(tt * 0.07)); // tail
        lq[6] = new Quaternionf().rotateY(tt * 0.025f);                                   // floating_armor
        lq[7] = new Quaternionf().rotateX(pelerin);                                       // cape

        Matrix4f[] m = new Matrix4f[n];
        for (int i = 0; i < n; i++) {
            float[] pv = AsmadeusRig.PIVOT[i];
            Matrix4f local = new Matrix4f().translate(pv[0], pv[1], pv[2]).rotate(lq[i]).translate(-pv[0], -pv[1], -pv[2]);
            int p = AsmadeusRig.PARENT[i];
            m[i] = p < 0 ? local : new Matrix4f(m[p]).mul(local);
        }
        float sc = (float) olcek;
        Quaternionf govde = new Quaternionf().rotationY((float) yaw).rotateX(gövdeEgim);
        Transformation[] out = new Transformation[n];
        for (int i = 0; i < n; i++) {
            Matrix4f full = new Matrix4f().scale(sc).rotate(govde).mul(m[i]);
            Vector3f tr = full.getTranslation(new Vector3f());
            Quaternionf r = full.getUnnormalizedRotation(new Quaternionf()).normalize();
            out[i] = new Transformation(tr, r, new Vector3f(sc, sc, sc), new Quaternionf());
        }
        return out;
    }

    private void gorselGuncelle() {
        Transformation[] tr = poz();
        Location l = govdeKonumu();
        for (int i = 0; i < parcalar.length; i++) {
            ItemDisplay d = parcalar[i];
            if (d == null || d.isDead()) continue;
            d.setTeleportDuration(2);
            d.teleport(l);
            d.setInterpolationDuration(2);
            d.setInterpolationDelay(0);
            d.setTransformation(tr[i]);
        }
    }

    private void animBaslat(Anim a, int uzun) {
        anim = a;
        animT = 0;
        animUzun = uzun;
    }

    // ================================================================== ana döngü

    private Player aktifHedef() {
        return in.enYakin(ent.getLocation(), 80);
    }

    private void tick() {
        if (in.durum != Instance.Durum.CALISIYOR) {
            kaldir();
            return;
        }
        if (!ent.isValid() || ent.isDead()) {
            if (!olu) {
                olu = true;
                oluT = 0;
                mermiler.clear();
                cemberler.clear();
                Location c = govdeKonumu();
                c.getWorld().playSound(c, Sound.ENTITY_WITHER_DEATH, SoundCategory.HOSTILE, 3f, 0.6f);
                c.getWorld().spawnParticle(Particle.SOUL, c, 80, 1.5, 2, 1.5, 0.05);
            }
            oluT++;
            if (oluT % 3 == 0) {
                Location c = govdeKonumu();
                c.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, c, 20, 1.2, 2, 1.2, 0.03);
            }
            yaw += 0.15;
            gorselGuncelle();
            if (oluT > 45) kaldir();
            return;
        }
        t++;
        animT++;
        if (anim != Anim.IDLE && animT >= animUzun) anim = Anim.IDLE;

        // faz 2
        if (!faz2 && bilgi != null && bilgi.canYuzde() <= 0.5) {
            faz2 = true;
            in.herkeseBaslik("§4§lASMADEUS ÖFKELENDİ", "§7Ruhlar çığlık atıyor!");
            ent.getWorld().playSound(ent.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.HOSTILE, 3f, 0.5f);
            if (bilgi.bar != null) bilgi.bar.setColor(BarColor.RED);
            baslatYetenek(Yetenek.CAGRI);
        }

        hareket();

        // yetenek akışı
        if (aktif != null) {
            yetenekTick();
        } else {
            bekleme--;
            if (bekleme <= 0 && aktifHedef() != null) {
                Yetenek[] l = Yetenek.values();
                Yetenek y;
                do {
                    y = l[rnd.nextInt(l.length)];
                } while (y == son && l.length > 1);
                baslatYetenek(y);
            }
        }
        mermileriIsle();
        // süs: kılıçtan ruh alevi
        if (t % 4 == 0) {
            Location c = govdeKonumu();
            c.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, c.clone().add(0, -1.6 * olcek * 0.6, 0), 2, 0.6, 0.3, 0.6, 0.01);
        }
        gorselGuncelle();
    }

    private void hareket() {
        Player p = aktifHedef();
        Location e = ent.getLocation();
        double yuk = in.pl.getConfig().getDouble("asmadeus.havada-yukseklik", 1.6);
        double hedefY = oda.oy + yuk + 0.25 * Math.sin(t * 0.08);
        double hiz = faz2 ? 0.2 : 0.14;
        if (aktif == Yetenek.CEKIM || aktif == Yetenek.CEMBER || aktif == Yetenek.MERMI || aktif == Yetenek.CAGRI) hiz = 0.03;
        if (aktif == Yetenek.KILIC) hiz = yetT < 12 ? 0.08 : 0.01;
        double nx = e.getX(), nz = e.getZ();
        hareketHizi = 0;
        if (p != null && aktif != Yetenek.GOLGE) {
            Vector v = p.getLocation().toVector().subtract(e.toVector());
            v.setY(0);
            double d = v.length();
            if (d > 0.01) {
                Vector yon = v.clone().normalize();
                bakis = yon;
                double hedefYaw = Math.atan2(-yon.getX(), -yon.getZ());
                double fark = hedefYaw - yaw;
                while (fark > Math.PI) fark -= 2 * Math.PI;
                while (fark < -Math.PI) fark += 2 * Math.PI;
                yaw += Math.max(-0.12, Math.min(0.12, fark));
                if (d > 9) {
                    nx += yon.getX() * hiz;
                    nz += yon.getZ() * hiz;
                    hareketHizi = hiz;
                } else if (d < 5) {
                    nx -= yon.getX() * hiz * 0.6;
                    nz -= yon.getZ() * hiz * 0.6;
                }
            }
        }
        // arena sınırları
        nx = Math.max(oda.x0 + 4, Math.min(oda.x0 + oda.len - 4, nx));
        nz = Math.max(oda.oz - oda.hw + 4, Math.min(oda.oz + oda.hw - 4, nz));
        double ny = e.getY() + (hedefY - e.getY()) * 0.1;
        Location yeni = new Location(e.getWorld(), nx, ny, nz, 0, 0);
        ent.teleport(yeni);
        ent.setVelocity(new Vector(0, 0, 0));
    }

    // ================================================================== yetenekler

    private void baslatYetenek(Yetenek y) {
        aktif = y;
        son = y;
        yetT = 0;
        bekleme = faz2 ? 45 : 75;
    }

    private void bitirYetenek() {
        aktif = null;
        bekleme = (faz2 ? 40 : 70) + rnd.nextInt(30);
    }

    private void yetenekTick() {
        yetT++;
        Player hedef = aktifHedef();
        Location govde = govdeKonumu();
        switch (aktif) {
            case KILIC -> {
                if (yetT == 1) {
                    animBaslat(Anim.SLASH, 30);
                    govde.getWorld().playSound(govde, Sound.ENTITY_WITHER_SHOOT, SoundCategory.HOSTILE, 2f, 0.6f);
                }
                if (yetT == 14) {
                    dalgaYon = hedef != null
                            ? hedef.getLocation().toVector().subtract(ent.getLocation().toVector()).setY(0).normalize()
                            : bakis.clone();
                    dalga(dalgaYon);
                    if (faz2) {
                        dalga(dalgaYon.clone().rotateAroundY(Math.toRadians(28)));
                        dalga(dalgaYon.clone().rotateAroundY(Math.toRadians(-28)));
                    }
                    govde.getWorld().playSound(govde, Sound.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.HOSTILE, 3f, 0.5f);
                }
                if (yetT > 34) bitirYetenek();
            }
            case MERMI -> {
                if (yetT == 1) animBaslat(Anim.CAST, 34);
                if (yetT == 12) {
                    int adet = faz2 ? 10 : 6;
                    List<Player> ps = in.aktifOyuncular();
                    for (int i = 0; i < adet && !ps.isEmpty(); i++) {
                        Mermi m = new Mermi();
                        m.konum = govde.clone().add(0, 0.8 * olcek, 0);
                        Player h = ps.get(i % ps.size());
                        m.hedef = h;
                        Vector yon = h.getEyeLocation().toVector().subtract(m.konum.toVector()).normalize();
                        yon.rotateAroundY(Math.toRadians((i - adet / 2.0) * 9));
                        m.hiz = yon.multiply(0.75);
                        mermiler.add(m);
                    }
                    govde.getWorld().playSound(govde, Sound.ENTITY_WITHER_SHOOT, SoundCategory.HOSTILE, 3f, 1.2f);
                }
                if (yetT > 36) bitirYetenek();
            }
            case GOLGE -> {
                if (yetT == 1 && hedef != null) {
                    govde.getWorld().spawnParticle(Particle.LARGE_SMOKE, govde, 60, 1, 2, 1, 0.05);
                    govde.getWorld().playSound(govde, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 3f, 0.4f);
                    golgeHedef = hedef.getLocation().clone();
                    gizle(true);
                }
                if (yetT == 14 && hedef != null) {
                    Vector arka = hedef.getLocation().getDirection().setY(0);
                    if (arka.lengthSquared() < 0.01) arka = new Vector(1, 0, 0);
                    arka.normalize().multiply(-3.5);
                    Location nl = hedef.getLocation().clone().add(arka);
                    nl.setY(oda.oy + in.pl.getConfig().getDouble("asmadeus.havada-yukseklik", 1.6));
                    ent.teleport(nl);
                    Vector yon = hedef.getLocation().toVector().subtract(nl.toVector()).setY(0);
                    if (yon.lengthSquared() > 0.01) {
                        yon.normalize();
                        yaw = Math.atan2(-yon.getX(), -yon.getZ());
                        bakis = yon;
                    }
                    gizle(false);
                    govdeKonumu().getWorld().spawnParticle(Particle.LARGE_SMOKE, govdeKonumu(), 60, 1, 2, 1, 0.05);
                }
                if (yetT == 22) animBaslat(Anim.SLASH, 30);
                if (yetT == 32) {
                    Location c = ent.getLocation();
                    c.getWorld().playSound(c, Sound.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.HOSTILE, 3f, 0.5f);
                    c.getWorld().spawnParticle(Particle.SWEEP_ATTACK, c.clone().add(bakis.clone().multiply(2.5)).add(0, 1.5, 0), 6, 1.5, 0.5, 1.5, 0);
                    for (Player p : in.aktifOyuncular()) {
                        if (p.getLocation().distanceSquared(c) <= 6 * 6) {
                            p.damage(30 * hasarCarpan, ent);
                            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0));
                            itme(p, c, 1.1, 0.5);
                        }
                    }
                }
                if (yetT > 42) bitirYetenek();
            }
            case CEMBER -> {
                if (yetT == 1) {
                    animBaslat(Anim.CAST, 70);
                    cemberler.clear();
                    for (Player p : in.aktifOyuncular()) cemberler.add(p.getLocation().clone());
                    if (faz2) {
                        for (int i = 0; i < 4; i++) cemberler.add(oda.rastgele(in.w, rnd));
                    }
                    herkesePatlamaUyari();
                }
                if (yetT < 45 && yetT % 2 == 0) {
                    for (Location c : cemberler) daire(c, 3.0, Particle.DUST, new Particle.DustOptions(Color.fromRGB(190, 0, 20), 1.6f));
                }
                if (yetT == 45) {
                    for (Location c : cemberler) {
                        c.getWorld().spawnParticle(Particle.EXPLOSION, c.clone().add(0, 0.5, 0), 4, 1.2, 0.3, 1.2, 0);
                        c.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, c.clone().add(0, 1, 0), 60, 1.5, 1.5, 1.5, 0.1);
                        c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 2f, 0.7f);
                        for (Player p : in.aktifOyuncular()) {
                            if (p.getLocation().distanceSquared(c) <= 3.3 * 3.3) {
                                p.damage(35 * hasarCarpan, ent);
                                itme(p, c, 0.6, 0.7);
                            }
                        }
                    }
                    cemberler.clear();
                }
                if (yetT > 52) bitirYetenek();
            }
            case CAGRI -> {
                if (yetT == 1) animBaslat(Anim.CAST, 50);
                if (yetT == 22) {
                    long mevcut = in.moblar.values().stream()
                            .filter(m -> m.anahtar.equals("asmadeus_minyon") && m.varlik != null && m.varlik.isValid()).count();
                    int adet = (int) Math.max(0, Math.min(faz2 ? 10 : 6, 14 - mevcut));
                    for (int i = 0; i < adet; i++) {
                        Location l = oda.rastgele(in.w, rnd);
                        l.getWorld().spawnParticle(Particle.SOUL, l.clone().add(0, 1, 0), 25, 0.4, 1, 0.4, 0.05);
                        in.minyon(WitherSkeleton.class, l, "asmadeus_minyon", 100, w -> {
                            w.getEquipment().setItemInMainHand(new ItemStack(Material.STONE_SWORD));
                        });
                    }
                    govde.getWorld().playSound(govde, Sound.ENTITY_EVOKER_PREPARE_SUMMON, SoundCategory.HOSTILE, 3f, 0.6f);
                }
                if (yetT > 50) bitirYetenek();
            }
            case CEKIM -> {
                if (yetT == 1) {
                    animBaslat(Anim.SLAM, 40);
                    govde.getWorld().playSound(govde, Sound.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.HOSTILE, 3f, 0.6f);
                }
                if (yetT >= 4 && yetT <= 36) {
                    Location c = ent.getLocation();
                    daire(c.clone().add(0, 0.3, 0), 10 - (yetT - 4) * 0.25, Particle.SOUL_FIRE_FLAME, null);
                    for (Player p : in.aktifOyuncular()) {
                        Vector v = c.toVector().subtract(p.getLocation().toVector()).setY(0);
                        double d = v.length();
                        if (d > 3 && d < 38) {
                            p.setVelocity(p.getVelocity().add(v.normalize().multiply(0.11)));
                        }
                    }
                }
                if (yetT == 38) {
                    Location c = ent.getLocation();
                    c.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, c.clone().add(0, 0.5 - 1.6, 0), 3, 2, 0.2, 2, 0);
                    c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 3f, 0.5f);
                    c.getWorld().playSound(c, Sound.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.HOSTILE, 3f, 0.6f);
                    for (Player p : in.aktifOyuncular()) {
                        if (p.getLocation().distanceSquared(c) <= 9 * 9) {
                            p.damage(38 * hasarCarpan, ent);
                            p.setVelocity(p.getVelocity().add(new Vector(0, 1.0, 0)));
                        }
                    }
                }
                if (yetT > 46) bitirYetenek();
            }
        }
    }

    private void herkesePatlamaUyari() {
        for (Player p : in.aktifOyuncular()) {
            p.sendActionBar(net.kyori.adventure.text.Component.text("Kırmızı çemberlerden çık!",
                    net.kyori.adventure.text.format.NamedTextColor.RED));
            p.playSound(p.getLocation(), Sound.BLOCK_BELL_USE, 1f, 0.5f);
        }
    }

    private void gizle(boolean gizli) {
        for (ItemDisplay d : parcalar) {
            if (d != null && !d.isDead()) d.setViewRange(gizli ? 0f : 5f);
        }
    }

    private void itme(Player p, Location merkez, double guc, double yukari) {
        Vector v = p.getLocation().toVector().subtract(merkez.toVector()).setY(0);
        if (v.lengthSquared() < 0.01) v = new Vector(1, 0, 0);
        p.setVelocity(p.getVelocity().add(v.normalize().multiply(guc).setY(yukari)));
    }

    private void daire(Location c, double r, Particle tur, Object veri) {
        int n = 28;
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            Location l = c.clone().add(Math.cos(a) * r, 0.15, Math.sin(a) * r);
            if (veri != null) c.getWorld().spawnParticle(tur, l, 1, 0, 0, 0, 0, veri);
            else c.getWorld().spawnParticle(tur, l, 1, 0, 0, 0, 0);
        }
    }

    /** Ölüm Kılıcı dalgası: koni içindeki oyunculara hasar + görsel çizgi. */
    private void dalga(Vector yon) {
        Location bas = ent.getLocation().clone().add(0, 1.0, 0);
        double menzil = 24;
        for (double d = 2; d <= menzil; d += 1.0) {
            Location pt = bas.clone().add(yon.clone().multiply(d));
            pt.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, pt, 6, 1.6, 0.4, 1.6, 0.02);
            if (((int) d) % 3 == 0) pt.getWorld().spawnParticle(Particle.SWEEP_ATTACK, pt, 1, 0, 0, 0, 0);
        }
        for (Player p : in.aktifOyuncular()) {
            Vector v = p.getLocation().toVector().subtract(bas.toVector());
            double boyunca = v.dot(yon);
            if (boyunca < 0 || boyunca > menzil) continue;
            Vector yanal = v.clone().subtract(yon.clone().multiply(boyunca));
            if (yanal.setY(0).length() <= 3.6 && Math.abs(v.getY()) < 5) {
                p.damage(28 * hasarCarpan, ent);
                itme(p, bas, 1.2, 0.45);
            }
        }
    }

    private void mermileriIsle() {
        for (Iterator<Mermi> it = mermiler.iterator(); it.hasNext(); ) {
            Mermi m = it.next();
            m.omur--;
            if (m.hedef != null && m.hedef.isOnline() && m.hedef.getWorld().equals(m.konum.getWorld()) && m.omur > 20) {
                Vector ist = m.hedef.getEyeLocation().toVector().subtract(m.konum.toVector()).normalize().multiply(0.75);
                m.hiz = m.hiz.multiply(0.92).add(ist.multiply(0.08)).normalize().multiply(0.75);
            }
            m.konum.add(m.hiz);
            m.konum.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, m.konum, 4, 0.1, 0.1, 0.1, 0.01);
            m.konum.getWorld().spawnParticle(Particle.SOUL, m.konum, 1, 0.05, 0.05, 0.05, 0.01);
            boolean bitti = m.omur <= 0 || !m.konum.getBlock().isPassable();
            if (!bitti) {
                for (Player p : in.aktifOyuncular()) {
                    if (p.getBoundingBox().expand(0.6).contains(m.konum.toVector())) {
                        p.damage(16 * hasarCarpan, ent);
                        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
                        bitti = true;
                        break;
                    }
                }
            }
            if (bitti) {
                m.konum.getWorld().spawnParticle(Particle.SOUL, m.konum, 12, 0.3, 0.3, 0.3, 0.05);
                it.remove();
            }
        }
    }

    // ================================================================== temizlik

    public void kaldir() {
        if (gorev != null) {
            try {
                gorev.cancel();
            } catch (IllegalStateException ignored) {
                // zaten iptal
            }
            gorev = null;
        }
        for (int i = 0; i < parcalar.length; i++) {
            if (parcalar[i] != null && !parcalar[i].isDead()) parcalar[i].remove();
            parcalar[i] = null;
        }
        mermiler.clear();
    }

    /** Test komutu için: sahnesiz statik gösterim. */
    public static List<ItemDisplay> vitrin(org.bukkit.World w, Location l, double olcek, String varyant) {
        List<ItemDisplay> liste = new ArrayList<>();
        String v = (varyant == null || varyant.equalsIgnoreCase("a")) ? "" : "_b";
        Matrix4f[] m = new Matrix4f[AsmadeusRig.NAMES.length];
        for (int i = 0; i < m.length; i++) {
            float[] pv = AsmadeusRig.PIVOT[i];
            m[i] = new Matrix4f();
        }
        float sc = (float) olcek;
        for (int i = 0; i < AsmadeusRig.NAMES.length; i++) {
            ItemStack it = new ItemStack(Material.PAPER);
            ItemMeta meta = it.getItemMeta();
            meta.setItemModel(new NamespacedKey("zindan", "asmadeus" + v + "/" + AsmadeusRig.NAMES[i]));
            it.setItemMeta(meta);
            Location at = l.clone().add(0, 1.5 * olcek, 0);
            ItemDisplay d = w.spawn(at, ItemDisplay.class, e -> {
                e.setItemStack(it);
                e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                e.setBillboard(Display.Billboard.FIXED);
                e.setViewRange(5.0f);
                e.setDisplayWidth(80f);
                e.setDisplayHeight(80f);
                e.setBrightness(new Display.Brightness(15, 15));
                e.setPersistent(false);
                e.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(sc, sc, sc), new Quaternionf()));
                e.addScoreboardTag("zd_parca");
            });
            liste.add(d);
        }
        return liste;
    }

    public UUID id() {
        return ent.getUniqueId();
    }
}
